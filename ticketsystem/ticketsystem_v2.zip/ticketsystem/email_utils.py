import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

# ── Configure these in your environment or .env file ──
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.example.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "noreply@example.com")
SMTP_PASS = os.getenv("SMTP_PASS", "your_smtp_password")
FROM_NAME = os.getenv("FROM_NAME", "Support Ticketsystem")
APP_URL   = os.getenv("APP_URL", "http://localhost:8000")

def _send(to_email: str, subject: str, html: str):
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{FROM_NAME} <{SMTP_USER}>"
        msg["To"] = to_email
        msg.attach(MIMEText(html, "html"))
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(SMTP_USER, to_email, msg.as_string())
    except Exception as e:
        print(f"[EMAIL ERROR] {e}")

def send_ticket_created_email(to_email: str, name: str, ticket):
    subject = f"✅ Ticket #{ticket.id} erstellt: {ticket.title}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Ihr Ticket wurde erstellt</h2>
      <p>Hallo {name},</p>
      <p>Ihr Support-Ticket wurde erfolgreich erstellt.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td>
            <td style="padding:8px;">#{ticket.id}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td>
            <td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Priorität</td>
            <td style="padding:8px;">{ticket.priority_label}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Status</td>
            <td style="padding:8px;">{ticket.status_label}</td></tr>
      </table>
      <a href="{APP_URL}/portal/ticket/{ticket.id}"
         style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;
                text-decoration:none;border-radius:6px;">Ticket ansehen</a>
      <p style="color:#64748b;margin-top:24px;font-size:13px;">
        Sie erhalten diese E-Mail, weil Sie ein Support-Ticket erstellt haben.
      </p>
    </div>"""
    _send(to_email, subject, html)

def send_ticket_updated_email(to_email: str, name: str, ticket,
                              comment_added: bool = False):
    if comment_added:
        subject = f"💬 Neuer Kommentar zu Ticket #{ticket.id}"
        action = "Ein neuer Kommentar wurde zu Ihrem Ticket hinzugefügt."
    else:
        subject = f"🔄 Status-Update: Ticket #{ticket.id}"
        action = f"Der Status Ihres Tickets wurde aktualisiert auf: <strong>{ticket.status_label}</strong>"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Ticket-Update</h2>
      <p>Hallo {name},</p>
      <p>{action}</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td>
            <td style="padding:8px;">#{ticket.id}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td>
            <td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Status</td>
            <td style="padding:8px;">{ticket.status_label}</td></tr>
      </table>
      <a href="{APP_URL}/portal/ticket/{ticket.id}"
         style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;
                text-decoration:none;border-radius:6px;">Ticket ansehen</a>
    </div>"""
    _send(to_email, subject, html)

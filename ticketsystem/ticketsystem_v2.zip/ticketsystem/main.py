from fastapi import FastAPI, Depends, HTTPException, status, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional
import uvicorn

from database import get_db, engine, Base
from models import User, Ticket, Comment, TicketStatus, TicketPriority
from auth import (
    authenticate_user, create_access_token, get_current_user,
    get_password_hash, ACCESS_TOKEN_EXPIRE_MINUTES
)
from email_utils import send_ticket_created_email, send_ticket_updated_email
import schemas

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Ticket System")

templates = Jinja2Templates(directory="templates")

# ─── AUTH ROUTES ────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(request: Request, db: Session = Depends(get_db),
                email: str = Form(...), password: str = Form(...)):
    user = authenticate_user(db, email, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Ungültige E-Mail oder Passwort"
        })
    access_token = create_access_token(data={"sub": str(user.id)})
    if user.is_admin:
        response = RedirectResponse(url="/admin", status_code=302)
    else:
        response = RedirectResponse(url="/portal", status_code=302)
    response.set_cookie("access_token", access_token, httponly=True)
    return response

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie("access_token")
    return response

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(request: Request, db: Session = Depends(get_db),
                   name: str = Form(...), email: str = Form(...),
                   password: str = Form(...), feuerwehr: str = Form(...),
                   loeschbezirk: str = Form(...), telefon: str = Form(...)):
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        return templates.TemplateResponse("register.html", {
            "request": request, "error": "E-Mail bereits registriert"
        })
    user = User(name=name, email=email,
                hashed_password=get_password_hash(password),
                feuerwehr=feuerwehr, loeschbezirk=loeschbezirk, telefon=telefon)
    db.add(user)
    db.commit()
    return RedirectResponse(url="/login?registered=1", status_code=302)

# ─── CUSTOMER PORTAL ────────────────────────────────────────────
@app.get("/portal", response_class=HTMLResponse)
async def portal(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    tickets = db.query(Ticket).filter(Ticket.user_id == user.id)\
                .order_by(Ticket.created_at.desc()).all()
    return templates.TemplateResponse("portal.html", {
        "request": request, "user": user, "tickets": tickets
    })

@app.get("/portal/new", response_class=HTMLResponse)
async def new_ticket_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("new_ticket.html", {
        "request": request, "user": user,
        "priorities": TicketPriority, "statuses": TicketStatus
    })

@app.post("/portal/new")
async def create_ticket(request: Request, db: Session = Depends(get_db),
                        title: str = Form(...), description: str = Form(...),
                        priority: str = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = Ticket(
        title=title, description=description,
        priority=TicketPriority(priority),
        user_id=user.id
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    send_ticket_created_email(user.email, user.name, ticket)
    return RedirectResponse(url=f"/portal/ticket/{ticket.id}", status_code=302)

@app.get("/portal/ticket/{ticket_id}", response_class=HTMLResponse)
async def view_ticket(request: Request, ticket_id: int,
                      db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return templates.TemplateResponse("ticket_detail.html", {
        "request": request, "user": user,
        "ticket": ticket, "comments": comments
    })

@app.post("/portal/ticket/{ticket_id}/comment")
async def add_comment_customer(request: Request, ticket_id: int,
                               db: Session = Depends(get_db),
                               content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=False)
    db.add(comment)
    db.commit()
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

# ─── ADMIN PANEL ─────────────────────────────────────────────────
@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: Session = Depends(get_db),
                          status_filter: Optional[str] = None,
                          priority_filter: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    query = db.query(Ticket)
    if status_filter:
        query = query.filter(Ticket.status == TicketStatus(status_filter))
    if priority_filter:
        query = query.filter(Ticket.priority == TicketPriority(priority_filter))
    tickets = query.order_by(Ticket.created_at.desc()).all()
    stats = {
        "total": db.query(Ticket).count(),
        "open": db.query(Ticket).filter(Ticket.status == TicketStatus.open).count(),
        "in_progress": db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count(),
        "resolved": db.query(Ticket).filter(Ticket.status == TicketStatus.resolved).count(),
    }
    return templates.TemplateResponse("admin_dashboard.html", {
        "request": request, "user": user, "tickets": tickets,
        "stats": stats, "statuses": TicketStatus, "priorities": TicketPriority,
        "status_filter": status_filter, "priority_filter": priority_filter
    })

@app.get("/admin/ticket/{ticket_id}", response_class=HTMLResponse)
async def admin_view_ticket(request: Request, ticket_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return templates.TemplateResponse("admin_ticket.html", {
        "request": request, "user": user, "ticket": ticket,
        "comments": comments, "statuses": TicketStatus, "priorities": TicketPriority
    })

@app.post("/admin/ticket/{ticket_id}/update")
async def admin_update_ticket(request: Request, ticket_id: int,
                              db: Session = Depends(get_db),
                              status: str = Form(...),
                              priority: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    old_status = ticket.status
    ticket.status = TicketStatus(status)
    ticket.priority = TicketPriority(priority)
    ticket.updated_at = datetime.utcnow()
    db.commit()
    if old_status != ticket.status:
        customer = db.query(User).filter(User.id == ticket.user_id).first()
        if customer:
            send_ticket_updated_email(customer.email, customer.name, ticket)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/admin/ticket/{ticket_id}/comment")
async def admin_add_comment(request: Request, ticket_id: int,
                            db: Session = Depends(get_db),
                            content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=True)
    db.add(comment)
    db.commit()
    customer = db.query(User).filter(User.id == ticket.user_id).first()
    if customer:
        send_ticket_updated_email(customer.email, customer.name, ticket,
                                  comment_added=True)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    users = db.query(User).all()
    return templates.TemplateResponse("admin_users.html", {
        "request": request, "user": user, "users": users
    })

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

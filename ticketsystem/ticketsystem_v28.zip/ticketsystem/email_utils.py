import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

# ── Mailserver-Konfiguration ──
SMTP_HOST = os.getenv("SMTP_HOST", "server36.webgo24.de")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "web185p12")
SMTP_PASS = os.getenv("SMTP_PASS", "")
FROM_EMAIL  = os.getenv("FROM_EMAIL",  "ticket.mpfeuer@michaely.de")
FROM_NAME   = os.getenv("FROM_NAME",   "Support Ticketsystem")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "ticket.mpfeuer@michaely.de")
APP_URL     = os.getenv("APP_URL",     "http://192.168.178.181:8000")

def _send(to_email: str, subject: str, html: str):
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"{FROM_NAME} <{FROM_EMAIL}>"
        msg["To"]      = to_email
        msg.attach(MIMEText(html, "html"))
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(FROM_EMAIL, to_email, msg.as_string())
        print(f"[EMAIL] Gesendet an {to_email}: {subject}")
    except Exception as e:
        print(f"[EMAIL FEHLER] {e}")

def send_new_registration_email(user):
    subject = f"Neue Registrierung: {user.name}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Neue Registrierung</h2>
      <p>Ein neuer Nutzer hat sich registriert:</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Name</td><td style="padding:8px;">{user.name}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">E-Mail</td><td style="padding:8px;">{user.email}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Telefon</td><td style="padding:8px;">{user.telefon or '-'}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Feuerwehr</td><td style="padding:8px;">{user.feuerwehr or '-'}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Loeschbezirk</td><td style="padding:8px;">{user.loeschbezirk or '-'}</td></tr>
      </table>
      <a href="{APP_URL}/admin/users" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;">Nutzer ansehen</a>
    </div>"""
    _send(ADMIN_EMAIL, subject, html)

def send_new_ticket_admin_email(user, ticket):
    subject = f"Neues Ticket {ticket.ticket_number}: {ticket.title}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Neues Support-Ticket</h2>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td><td style="padding:8px;">{ticket.ticket_number}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td><td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Prioritaet</td><td style="padding:8px;">{ticket.priority_label}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Von</td><td style="padding:8px;">{user.name} ({user.email})</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Feuerwehr</td><td style="padding:8px;">{user.feuerwehr or '-'}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Loeschbezirk</td><td style="padding:8px;">{user.loeschbezirk or '-'}</td></tr>
      </table>
      <div style="background:#f8fafc;border-left:4px solid #2563eb;padding:12px;margin:16px 0;">
        <strong>Beschreibung:</strong><br>{ticket.description}
      </div>
      <a href="{APP_URL}/admin/ticket/{ticket.id}" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;">Ticket bearbeiten</a>
    </div>"""
    _send(ADMIN_EMAIL, subject, html)

def send_ticket_created_email(to_email: str, name: str, ticket):
    subject = f"Ticket {ticket.ticket_number} erstellt: {ticket.title}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Ihr Ticket wurde erstellt</h2>
      <p>Hallo {name},</p>
      <p>Ihr Support-Ticket wurde erfolgreich erstellt.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td><td style="padding:8px;">{ticket.ticket_number}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td><td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Prioritaet</td><td style="padding:8px;">{ticket.priority_label}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Status</td><td style="padding:8px;">{ticket.status_label}</td></tr>
      </table>
      <a href="{APP_URL}/portal/ticket/{ticket.id}" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;">Ticket ansehen</a>
    </div>"""
    _send(to_email, subject, html)

def send_ticket_updated_email(to_email: str, name: str, ticket,
                              comment_added: bool = False, comment_content: str = "",
                              sachbearbeiter: str = ""):
    if comment_added:
        subject = f"Neuer Kommentar zu Ticket {ticket.ticket_number}"
        action = "Ein neuer Kommentar wurde zu Ihrem Ticket hinzugefuegt."
    else:
        subject = f"Status-Update: Ticket {ticket.ticket_number}"
        action = f"Der Status Ihres Tickets wurde aktualisiert auf: <strong>{ticket.status_label}</strong>"
    comment_block = ""
    if comment_added and comment_content:
        sach_line = f"<p style='font-size:12px;color:#64748b;margin:4px 0 8px;'>Sachbearbeiter: <strong>{sachbearbeiter}</strong></p>" if sachbearbeiter else ""
        comment_block = f"""
      <p style="font-weight:bold;margin-top:16px;">Kommentar vom Support-Team:</p>
      {sach_line}
      <p style="background:#eff6ff;border-left:4px solid #2563eb;padding:12px;margin:8px 0;">{comment_content}</p>"""
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Ticket-Update</h2>
      <p>Hallo {name},</p>
      <p>{action}</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td><td style="padding:8px;">{ticket.ticket_number}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td><td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Status</td><td style="padding:8px;">{ticket.status_label}</td></tr>
      </table>
      {comment_block}
      <a href="{APP_URL}/portal/ticket/{ticket.id}" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;">Ticket ansehen</a>
    </div>"""
    _send(to_email, subject, html)

def send_registration_confirmation_email(user):
    subject = "Willkommen beim Ticketsystem!"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Registrierung erfolgreich!</h2>
      <p>Hallo {user.name},</p>
      <p>Ihr Konto wurde erfolgreich erstellt. Sie können sich jetzt anmelden.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Name</td><td style="padding:8px;">{user.name}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">E-Mail</td><td style="padding:8px;">{user.email}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Feuerwehr</td><td style="padding:8px;">{user.feuerwehr or '-'}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Loeschbezirk</td><td style="padding:8px;">{user.loeschbezirk or '-'}</td></tr>
      </table>
      <a href="{APP_URL}/login" style="display:inline-block;padding:10px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;">Jetzt anmelden</a>
      <p style="color:#64748b;margin-top:24px;font-size:13px;">Bei Fragen wenden Sie sich an uns.</p>
    </div>"""
    _send(user.email, subject, html)

def send_reminder_email(to_email: str, name: str, ticket):
    subject = f"Erinnerung: Ticket {ticket.ticket_number} wartet auf Bearbeitung"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#f59e0b;">Erinnerung: Offenes Ticket</h2>
      <p>Hallo {name},</p>
      <p>Ihr Support-Ticket ist seit mehr als 5 Tagen offen. Wir arbeiten daran!</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td><td style="padding:8px;">{ticket.ticket_number}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td><td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Status</td><td style="padding:8px;">{ticket.status_label}</td></tr>
      </table>
      <a href="{APP_URL}/portal/ticket/{ticket.id}" style="display:inline-block;padding:10px 20px;background:#f59e0b;color:#fff;text-decoration:none;border-radius:6px;">Ticket ansehen</a>
    </div>"""
    _send(to_email, subject, html)

def send_user_comment_admin_email(user, ticket, comment_content):
    subject = f"Nutzer-Antwort: {ticket.ticket_number} - {ticket.title}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#10b981;">Nutzer hat geantwortet</h2>
      <p>Der Nutzer hat einen neuen Kommentar zu seinem Ticket hinzugefuegt:</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;">
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Ticket-Nr.</td><td style="padding:8px;">{ticket.ticket_number}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Betreff</td><td style="padding:8px;">{ticket.title}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Von</td><td style="padding:8px;">{user.name} ({user.email})</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Feuerwehr</td><td style="padding:8px;">{user.feuerwehr or '-'}</td></tr>
        <tr><td style="padding:8px;background:#f1f5f9;font-weight:bold;">Funktion</td><td style="padding:8px;">{user.funktion or '-'}</td></tr>
      </table>
      <p style="font-weight:bold;">Kommentar des Nutzers:</p>
      <p style="background:#f0fdf4;border-left:4px solid #10b981;padding:12px;margin:16px 0;">{comment_content}</p>
      <a href="{APP_URL}/admin/ticket/{ticket.id}" style="display:inline-block;padding:10px 20px;background:#10b981;color:#fff;text-decoration:none;border-radius:6px;">Ticket ansehen</a>
    </div>"""
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{FROM_NAME} <{FROM_EMAIL}>"
        msg["To"] = ADMIN_EMAIL
        # Plaintext fallback
        plain = f"Nutzer-Antwort: {ticket.ticket_number}\n\nVon: {user.name}\nFeuerwehr: {user.feuerwehr or '-'}\n\nKommentar:\n{comment_content}\n\nTicket: {APP_URL}/admin/ticket/{ticket.id}"
        msg.attach(MIMEText(plain, "plain"))
        msg.attach(MIMEText(html, "html"))
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(FROM_EMAIL, ADMIN_EMAIL, msg.as_string())
        print(f"[EMAIL] Nutzer-Kommentar gesendet")
    except Exception as e:
        print(f"[EMAIL FEHLER] {e}")

def send_password_reset_email(to_email: str, name: str, token: str):
    subject = "Passwort zuruecksetzen - MP-Feuer-Ticketsystem"
    reset_url = f"{APP_URL}/reset-password/{token}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
      <h2 style="color:#2563eb;">Passwort zuruecksetzen</h2>
      <p>Hallo {name},</p>
      <p>Sie haben eine Anfrage zum Zuruecksetzen Ihres Passworts gestellt. Klicken Sie auf den Button um ein neues Passwort zu setzen:</p>
      <a href="{reset_url}" style="display:inline-block;padding:12px 24px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px;margin:16px 0;">Passwort zuruecksetzen</a>
      <p style="color:#64748b;font-size:13px;">Dieser Link ist 2 Stunden gueltig. Falls Sie keine Anfrage gestellt haben, ignorieren Sie diese E-Mail.</p>
    </div>"""
    _send(to_email, subject, html)

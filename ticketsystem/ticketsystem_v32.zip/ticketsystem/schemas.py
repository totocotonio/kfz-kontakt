from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class UserCreate(BaseModel):
    name: str
    email: str
    password: str

class TicketCreate(BaseModel):
    title: str
    description: str
    priority: str

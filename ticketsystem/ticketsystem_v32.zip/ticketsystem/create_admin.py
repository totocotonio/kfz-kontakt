#!/usr/bin/env python3
"""Run this once to create your admin account."""
from database import SessionLocal, engine, Base
from models import User
from auth import get_password_hash

Base.metadata.create_all(bind=engine)

db = SessionLocal()

email = input("Admin E-Mail: ")
name  = input("Admin Name:  ")
password = input("Passwort:    ")

existing = db.query(User).filter(User.email == email).first()
if existing:
    print("User existiert bereits!")
else:
    admin = User(name=name, email=email,
                 hashed_password=get_password_hash(password),
                 is_admin=True)
    db.add(admin)
    db.commit()
    print(f"✅ Admin '{name}' ({email}) wurde erstellt!")

db.close()

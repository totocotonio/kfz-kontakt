from fastapi import FastAPI, Depends, HTTPException, status, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional, List
import uvicorn
import os
import shutil
import asyncio
import threading
import time
import secrets
from zoneinfo import ZoneInfo

BERLIN = ZoneInfo("Europe/Berlin")

def now_berlin():
    from datetime import timezone
    return datetime.now(timezone.utc).astimezone(BERLIN).replace(tzinfo=None)

from database import get_db, engine, Base
from models import User, Ticket, Comment, TicketAttachment, TicketStatus, TicketPriority, AdminNote, TicketHistory, PasswordResetToken
from auth import (
    authenticate_user, create_access_token, get_current_user,
    get_password_hash, ACCESS_TOKEN_EXPIRE_MINUTES
)
from email_utils import (send_ticket_created_email, send_ticket_updated_email,
                         send_new_registration_email, send_new_ticket_admin_email,
                         send_registration_confirmation_email, send_reminder_email,
                         send_user_comment_admin_email, send_password_reset_email,
                         send_verification_email)
import schemas

Base.metadata.create_all(bind=engine)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI(title="MP-Feuer-Ticketsystem")
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ─── ERINNERUNGSMAIL HINTERGRUNDTASK ────────────────────────────
def reminder_task():
    """Läuft alle 24h, sendet Erinnerungen bei Tickets älter als 5 Tage."""
    while True:
        time.sleep(86400)  # 24 Stunden
        try:
            from database import SessionLocal
            db = SessionLocal()
            cutoff = datetime.utcnow() - timedelta(days=5)
            old_tickets = db.query(Ticket).filter(
                Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress]),
                Ticket.updated_at < cutoff
            ).all()
            for ticket in old_tickets:
                user = db.query(User).filter(User.id == ticket.user_id).first()
                if user:
                    send_reminder_email(user.email, user.name, ticket)
            db.close()
            print(f"[REMINDER] {len(old_tickets)} Erinnerungen gesendet")
        except Exception as e:
            print(f"[REMINDER FEHLER] {e}")

@app.on_event("startup")
async def startup_event():
    t = threading.Thread(target=reminder_task, daemon=True)
    t.start()
    print("[STARTUP] Erinnerungs-Task gestartet")

# ─── AUTH ROUTES ────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
@limiter.limit("5/minute")
async def login(request: Request, db: Session = Depends(get_db),
                email: str = Form(...), password: str = Form(...)):
    user = authenticate_user(db, email, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Ungültige E-Mail oder Passwort"
        })
    if not user.is_verified and not user.is_admin:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Bitte bestätigen Sie zuerst Ihre E-Mail-Adresse. Prüfen Sie Ihren Posteingang."
        })
    access_token = create_access_token(data={"sub": str(user.id)})
    if user.is_admin:
        response = RedirectResponse(url="/admin", status_code=302)
    else:
        response = RedirectResponse(url="/portal", status_code=302)
    response.set_cookie("access_token", access_token, httponly=True)
    return response

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie("access_token")
    return response

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(request: Request, db: Session = Depends(get_db),
                   name: str = Form(...), email: str = Form(...),
                   password: str = Form(...), feuerwehr: str = Form(...),
                   loeschbezirk: str = Form(...), telefon: str = Form(...),
                   funktion: str = Form(...)):
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        return templates.TemplateResponse("register.html", {
            "request": request, "error": "E-Mail bereits registriert"
        })
    user = User(name=name, email=email,
                hashed_password=get_password_hash(password),
                feuerwehr=feuerwehr, loeschbezirk=loeschbezirk,
                telefon=telefon, funktion=funktion,
                is_verified=False,
                verification_token=secrets.token_urlsafe(32))
    db.add(user)
    db.commit()
    db.refresh(user)
    send_new_registration_email(user)
    send_verification_email(user, user.verification_token)
    return RedirectResponse(url="/login?verify=1", status_code=302)

# ─── CUSTOMER PORTAL ────────────────────────────────────────────
@app.get("/portal", response_class=HTMLResponse)
async def portal(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    tickets = db.query(Ticket).filter(Ticket.user_id == user.id)\
                .order_by(Ticket.created_at.desc()).all()
    return templates.TemplateResponse("portal.html", {
        "request": request, "user": user, "tickets": tickets
    })

@app.get("/portal/new", response_class=HTMLResponse)
async def new_ticket_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("new_ticket.html", {
        "request": request, "user": user,
        "priorities": TicketPriority, "statuses": TicketStatus
    })

@app.post("/portal/new")
async def create_ticket(request: Request, db: Session = Depends(get_db),
                        title: str = Form(...), description: str = Form(...),
                        priority: str = Form(...),
                        files: List[UploadFile] = File(default=[])):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = Ticket(
        title=title, description=description,
        priority=TicketPriority(priority),
        user_id=user.id
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    # Dateien speichern
    ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc', '.docx', '.txt', '.zip'}
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB
    for file in files:
        if file.filename:
            ext = os.path.splitext(file.filename)[1].lower()
            if ext not in ALLOWED_EXTENSIONS:
                continue  # Unerlaubte Dateitypen überspringen
            contents = await file.read()
            if len(contents) > MAX_FILE_SIZE:
                continue  # Zu große Dateien überspringen
            import re
            safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename)
            filename = f"ticket_{ticket.id}_{int(time.time())}_{safe_filename}"
            filepath = os.path.join(UPLOAD_DIR, filename)
            with open(filepath, "wb") as f:
                f.write(contents)
            attachment = TicketAttachment(
                filename=file.filename,
                filepath=filename,
                ticket_id=ticket.id
            )
            db.add(attachment)
    db.commit()
    send_ticket_created_email(user.email, user.name, ticket)
    send_new_ticket_admin_email(user, ticket)
    return RedirectResponse(url=f"/portal/ticket/{ticket.id}", status_code=302)

@app.get("/portal/ticket/{ticket_id}", response_class=HTMLResponse)
async def view_ticket(request: Request, ticket_id: int,
                      db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.desc()).all()
    return templates.TemplateResponse("ticket_detail.html", {
        "request": request, "user": user,
        "ticket": ticket, "comments": comments
    })

@app.post("/portal/ticket/{ticket_id}/reopen")
async def reopen_ticket(request: Request, ticket_id: int,
                        db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    ticket.status = TicketStatus.open
    ticket.updated_at = now_berlin()
    ticket.last_user_activity = now_berlin()
    db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                         field="Status", old_value="closed/resolved",
                         new_value="open"))
    db.commit()
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

@app.post("/portal/ticket/{ticket_id}/close")
async def close_ticket_customer(request: Request, ticket_id: int,
                                db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    ticket.status = TicketStatus.closed
    ticket.updated_at = now_berlin()
    db.commit()
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

@app.post("/portal/ticket/{ticket_id}/comment")
async def add_comment_customer(request: Request, ticket_id: int,
                               db: Session = Depends(get_db),
                               content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=False)
    db.add(comment)
    ticket.last_user_activity = now_berlin()
    ticket.updated_at = now_berlin()
    db.commit()
    send_user_comment_admin_email(user, ticket, content)
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

# ─── ADMIN PANEL ─────────────────────────────────────────────────
@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: Session = Depends(get_db),
                          status_filter: Optional[str] = None,
                          priority_filter: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    query = db.query(Ticket)
    if status_filter:
        query = query.filter(Ticket.status == TicketStatus(status_filter))
    if priority_filter:
        query = query.filter(Ticket.priority == TicketPriority(priority_filter))
    tickets = query.order_by(Ticket.created_at.desc()).all()

    # Unbeantwortet: letzter Kommentar ist vom Nutzer (nicht Admin)
    all_tickets = db.query(Ticket).filter(
        Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress])
    ).all()
    unanswered = []
    for t in all_tickets:
        if t.comments:
            last_comment = sorted(t.comments, key=lambda c: c.created_at)[-1]
            if not last_comment.is_admin:
                unanswered.append(t)
        else:
            # Neues Ticket ohne Kommentare = immer unbeantwortet
            unanswered.append(t)

    stats = {
        "total": db.query(Ticket).count(),
        "open": db.query(Ticket).filter(Ticket.status == TicketStatus.open).count(),
        "in_progress": db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count(),
        "resolved": db.query(Ticket).filter(Ticket.status == TicketStatus.resolved).count(),
        "unanswered": len(unanswered),
    }
    return templates.TemplateResponse("admin_dashboard.html", {
        "request": request, "user": user, "tickets": tickets,
        "stats": stats, "statuses": TicketStatus, "priorities": TicketPriority,
        "status_filter": status_filter, "priority_filter": priority_filter,
        "unanswered_tickets": unanswered
    })

@app.get("/admin/ticket/{ticket_id}", response_class=HTMLResponse)
async def admin_view_ticket(request: Request, ticket_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.desc()).all()
    return templates.TemplateResponse("admin_ticket.html", {
        "request": request, "user": user, "ticket": ticket,
        "comments": comments, "statuses": TicketStatus, "priorities": TicketPriority
    })

@app.post("/admin/ticket/{ticket_id}/update")
async def admin_update_ticket(request: Request, ticket_id: int,
                              db: Session = Depends(get_db),
                              status: str = Form(...),
                              priority: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    old_status = ticket.status
    old_priority = ticket.priority
    ticket.status = TicketStatus(status)
    ticket.priority = TicketPriority(priority)
    ticket.updated_at = now_berlin()
    # Lösungszeit erfassen
    if ticket.status == TicketStatus.resolved and old_status != TicketStatus.resolved:
        ticket.resolved_at = now_berlin()
    # History aufzeichnen
    if old_status != ticket.status:
        db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                             field="Status", old_value=old_status.value,
                             new_value=ticket.status.value))
    if old_priority != ticket.priority:
        db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                             field="Priorität", old_value=old_priority.value,
                             new_value=ticket.priority.value))
    db.commit()
    if old_status != ticket.status:
        customer = db.query(User).filter(User.id == ticket.user_id).first()
        if customer:
            send_ticket_updated_email(customer.email, customer.name, ticket)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/admin/ticket/{ticket_id}/comment")
async def admin_add_comment(request: Request, ticket_id: int,
                            db: Session = Depends(get_db),
                            content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=True)
    db.add(comment)
    # Erste Reaktionszeit erfassen
    if not ticket.first_response_at:
        ticket.first_response_at = now_berlin()
    ticket.updated_at = now_berlin()
    db.commit()
    customer = db.query(User).filter(User.id == ticket.user_id).first()
    if customer:
        send_ticket_updated_email(customer.email, customer.name, ticket,
                                  comment_added=True, comment_content=content,
                                  sachbearbeiter=user.name)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/admin/users/{user_id}/delete")
async def admin_delete_user(request: Request, user_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    target = db.query(User).filter(User.id == user_id).first()
    if not target or target.is_admin:
        raise HTTPException(status_code=403, detail="Nicht erlaubt")
    # Kommentare und Tickets des Nutzers auch löschen
    for ticket in target.tickets:
        db.query(Comment).filter(Comment.ticket_id == ticket.id).delete()
    db.query(Ticket).filter(Ticket.user_id == user_id).delete()
    db.query(Comment).filter(Comment.user_id == user_id).delete()
    db.delete(target)
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    users = db.query(User).all()
    return templates.TemplateResponse("admin_users.html", {
        "request": request, "user": user, "users": users
    })

@app.get("/admin/stats", response_class=HTMLResponse)
async def admin_stats(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    from sqlalchemy import func
    # Tickets pro Status
    status_counts = {s.value: db.query(Ticket).filter(Ticket.status == s).count() for s in TicketStatus}
    # Tickets pro Priorität
    priority_counts = {p.value: db.query(Ticket).filter(Ticket.priority == p).count() for p in TicketPriority}
    # Tickets pro Tag (letzte 30 Tage)
    tickets_per_day = []
    for i in range(29, -1, -1):
        day = datetime.utcnow() - timedelta(days=i)
        day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day.replace(hour=23, minute=59, second=59)
        count = db.query(Ticket).filter(
            Ticket.created_at >= day_start,
            Ticket.created_at <= day_end
        ).count()
        tickets_per_day.append({"date": day.strftime("%d.%m"), "count": count})
    # Überfällige Tickets (älter als 5 Tage, noch offen)
    cutoff = datetime.utcnow() - timedelta(days=5)
    overdue = db.query(Ticket).filter(
        Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress]),
        Ticket.updated_at < cutoff
    ).count()
    total = db.query(Ticket).count()
    users_count = db.query(User).filter(User.is_admin == False).count()

    # Reaktionszeiten berechnen
    tickets_with_response = db.query(Ticket).filter(
        Ticket.first_response_at != None
    ).all()
    tickets_resolved = db.query(Ticket).filter(
        Ticket.resolved_at != None
    ).all()

    avg_response_hours = 0
    avg_resolve_hours = 0
    if tickets_with_response:
        total_hours = sum(
            (t.first_response_at - t.created_at).total_seconds() / 3600
            for t in tickets_with_response
        )
        avg_response_hours = round(total_hours / len(tickets_with_response), 1)
    if tickets_resolved:
        total_hours = sum(
            (t.resolved_at - t.created_at).total_seconds() / 3600
            for t in tickets_resolved
        )
        avg_resolve_hours = round(total_hours / len(tickets_resolved), 1)

    # Reaktionszeiten pro Monat (letzte 6 Monate)
    monthly_stats = []
    for i in range(5, -1, -1):
        from datetime import timezone
        month_start = (datetime.now() - timedelta(days=i*30)).replace(day=1, hour=0, minute=0, second=0)
        month_end = (month_start + timedelta(days=32)).replace(day=1)
        month_tickets = db.query(Ticket).filter(
            Ticket.created_at >= month_start,
            Ticket.created_at < month_end,
            Ticket.first_response_at != None
        ).all()
        if month_tickets:
            avg = sum((t.first_response_at - t.created_at).total_seconds() / 3600 for t in month_tickets) / len(month_tickets)
        else:
            avg = 0
        monthly_stats.append({
            "month": month_start.strftime("%b %Y"),
            "avg_hours": round(avg, 1),
            "count": len(month_tickets)
        })
    return templates.TemplateResponse("admin_stats.html", {
        "request": request, "user": user,
        "status_counts": status_counts,
        "priority_counts": priority_counts,
        "tickets_per_day": tickets_per_day,
        "overdue": overdue, "total": total,
        "users_count": users_count,
        "avg_response_hours": avg_response_hours,
        "avg_resolve_hours": avg_resolve_hours,
        "monthly_stats": monthly_stats,
    })

# ─── PASSWORT VERGESSEN ──────────────────────────────────────────
# ─── E-MAIL VERIFIKATION ────────────────────────────────────────
@app.get("/verify-email/{token}", response_class=HTMLResponse)
async def verify_email(request: Request, token: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.verification_token == token).first()
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Ungültiger oder abgelaufener Bestätigungslink."
        })
    user.is_verified = True
    user.verification_token = None
    db.commit()
    send_registration_confirmation_email(user)
    return RedirectResponse(url="/login?registered=1", status_code=302)

@app.get("/forgot-password", response_class=HTMLResponse)
async def forgot_password_page(request: Request):
    return templates.TemplateResponse("forgot_password.html", {"request": request})

@app.post("/forgot-password")
async def forgot_password(request: Request, db: Session = Depends(get_db),
                          email: str = Form(...)):
    user = db.query(User).filter(User.email == email).first()
    if user:
        token = secrets.token_urlsafe(32)
        reset = PasswordResetToken(
            token=token, user_id=user.id,
            expires_at=now_berlin() + timedelta(hours=2)
        )
        db.add(reset)
        db.commit()
        send_password_reset_email(user.email, user.name, token)
    return templates.TemplateResponse("forgot_password.html", {
        "request": request,
        "success": "Falls die E-Mail registriert ist, wurde ein Reset-Link gesendet."
    })

@app.get("/reset-password/{token}", response_class=HTMLResponse)
async def reset_password_page(request: Request, token: str, db: Session = Depends(get_db)):
    reset = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > now_berlin()
    ).first()
    if not reset:
        return templates.TemplateResponse("reset_password.html", {
            "request": request, "error": "Link ungültig oder abgelaufen."
        })
    return templates.TemplateResponse("reset_password.html", {
        "request": request, "token": token
    })

@app.post("/reset-password/{token}")
async def reset_password(request: Request, token: str, db: Session = Depends(get_db),
                         password: str = Form(...)):
    reset = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > now_berlin()
    ).first()
    if not reset:
        return templates.TemplateResponse("reset_password.html", {
            "request": request, "error": "Link ungültig oder abgelaufen."
        })
    user = db.query(User).filter(User.id == reset.user_id).first()
    user.hashed_password = get_password_hash(password)
    reset.used = True
    db.commit()
    return RedirectResponse(url="/login?reset=1", status_code=302)

# ─── PROFIL BEARBEITEN ───────────────────────────────────────────
@app.get("/portal/profil", response_class=HTMLResponse)
async def profil_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("profil.html", {"request": request, "user": user})

@app.post("/portal/profil")
async def profil_update(request: Request, db: Session = Depends(get_db),
                        name: str = Form(...), telefon: str = Form(...),
                        funktion: str = Form(...), feuerwehr: str = Form(...),
                        loeschbezirk: str = Form(...),
                        password: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    user.name = name
    user.telefon = telefon
    user.funktion = funktion
    user.feuerwehr = feuerwehr
    user.loeschbezirk = loeschbezirk
    if password:
        user.hashed_password = get_password_hash(password)
    db.commit()
    return templates.TemplateResponse("profil.html", {
        "request": request, "user": user,
        "success": "Profil erfolgreich gespeichert!"
    })

# ─── ADMIN NOTIZEN ───────────────────────────────────────────────
@app.post("/admin/ticket/{ticket_id}/note")
async def admin_add_note(request: Request, ticket_id: int,
                         db: Session = Depends(get_db),
                         content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    note = AdminNote(content=content, ticket_id=ticket_id, admin_id=user.id)
    db.add(note)
    db.commit()
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

# ─── PDF EXPORT ─────────────────────────────────────────────────
@app.get("/portal/ticket/{ticket_id}/pdf")
async def ticket_pdf_customer(request: Request, ticket_id: int,
                               db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return _generate_ticket_pdf(ticket, comments)

@app.get("/admin/ticket/{ticket_id}/pdf")
async def ticket_pdf_admin(request: Request, ticket_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return _generate_ticket_pdf(ticket, comments)

def _generate_ticket_pdf(ticket, comments):
    from fastapi.responses import Response
    comments_html = ""
    for c in comments:
        bg = "#e8f0fe" if c.is_admin else "#f5f5f5"
        author = f"Support-Team ({c.user.name})" if c.is_admin else f"{c.user.name}"
        comments_html += f"""
        <div style="background:{bg};border-left:4px solid {'#2563eb' if c.is_admin else '#ccc'};
                    padding:10px;margin:8px 0;border-radius:4px;">
          <div style="font-size:11px;color:#666;margin-bottom:4px;">
            {author} &middot; {c.created_at.strftime('%d.%m.%Y %H:%M')}
          </div>
          <p style="margin:0;">{c.content}</p>
        </div>"""
    html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body {{ font-family: Arial, sans-serif; font-size: 13px; color: #333; margin: 40px; }}
  h1 {{ color: #2563eb; font-size: 20px; margin:0; }}
  .header {{ border-bottom: 2px solid #2563eb; padding-bottom: 10px; margin-bottom: 20px; }}
  table {{ width: 100%; border-collapse: collapse; margin: 16px 0; }}
  td {{ padding: 8px; border-bottom: 1px solid #eee; }}
  td:first-child {{ font-weight: bold; width: 150px; background: #f8f9fa; }}
  .description {{ background: #f8f9fa; padding: 12px; border-radius: 4px; margin: 16px 0; white-space: pre-wrap; }}
  .footer {{ margin-top: 30px; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }}
</style>
</head><body>
<div class="header">
  <h1>MP-Feuer-Ticketsystem - Landkreis Saarlouis</h1>
  <h2 style="margin:4px 0;font-size:16px;">{ticket.ticket_number}: {ticket.title}</h2>
</div>
<table>
  <tr><td>Ticket-Nr.</td><td>{ticket.ticket_number}</td></tr>
  <tr><td>Status</td><td>{ticket.status_label}</td></tr>
  <tr><td>Prioritaet</td><td>{ticket.priority_label}</td></tr>
  <tr><td>Erstellt von</td><td>{ticket.user.name} ({ticket.user.email})</td></tr>
  <tr><td>Feuerwehr</td><td>{ticket.user.feuerwehr or '-'}</td></tr>
  <tr><td>Loeschbezirk</td><td>{ticket.user.loeschbezirk or '-'}</td></tr>
  <tr><td>Funktion</td><td>{ticket.user.funktion or '-'}</td></tr>
  <tr><td>Erstellt am</td><td>{ticket.created_at.strftime('%d.%m.%Y %H:%M')}</td></tr>
  <tr><td>Zuletzt geaendert</td><td>{ticket.updated_at.strftime('%d.%m.%Y %H:%M')}</td></tr>
</table>
<h3>Beschreibung</h3>
<div class="description">{ticket.description}</div>
<h3>Kommunikation ({len(comments)} Nachrichten)</h3>
{comments_html}
<div class="footer">Gedruckt am {datetime.now().strftime('%d.%m.%Y %H:%M')} - MP-Feuer-Ticketsystem des Landkreises Saarlouis</div>
</body></html>"""
    try:
        import weasyprint
        pdf = weasyprint.HTML(string=html).write_pdf()
        from fastapi.responses import Response
        return Response(content=pdf, media_type="application/pdf",
                       headers={"Content-Disposition": f"attachment; filename={ticket.ticket_number}.pdf"})
    except ImportError:
        from fastapi.responses import Response
        return Response(content=html + "<script>window.print()</script>",
                       media_type="text/html")

# ─── OEFFENTLICHE STATUSSEITE ────────────────────────────────────
@app.get("/status", response_class=HTMLResponse)
async def public_status(request: Request, db: Session = Depends(get_db)):
    stats = {
        "open": db.query(Ticket).filter(Ticket.status == TicketStatus.open).count(),
        "in_progress": db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count(),
        "resolved": db.query(Ticket).filter(Ticket.status == TicketStatus.resolved).count(),
        "total": db.query(Ticket).count(),
    }
    return templates.TemplateResponse("public_status.html", {
        "request": request, "stats": stats
    })

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

# Changelog – MP-Feuer-Ticketsystem des Landkreises Saarlouis

Entwickelt von Torsten Michaely · © 2026

---

## v2.3.0 – Startseite & Einstellungen (2026-03-30)
- 🏠 Attraktive neue Startseite mit Hero-Design und Feature-Cards
- 🎨 Prioritätsfarben individuell anpassbar in Admin → Einstellungen
- ⚙️ Einstellungsseite mit System-Informationen
- Einstellungen im ⚙ Mehr Dropdown

## v2.2.0 – E-Mail-Vorschau & Druckansicht (2026-03-30)
- 👁 E-Mail-Vorschau vor dem Senden in der Massenmail
- 🖨 Drucken-Button im Ticket-Detail
- Optimierte Druckansicht (Navigation, Buttons etc. ausgeblendet)
- Saubere Darstellung beim Drucken und PDF-Export

## v2.1.0 – Nutzer & Kommunikation (2026-03-30)
- 💬 "Neue Antwort!" als gelesen markieren wenn Nutzer Ticket öffnet
- 📊 Tägliche Zusammenfassung per E-Mail um 7:30 Uhr
- 🚒 Statistik Tickets pro Gemeinde als Chart
- 📢 Massenmail an alle oder einzelne Gemeinden
- ⏸ Nutzer deaktivieren/sperren (statt nur löschen)
- Deaktivierte Nutzer können sich nicht mehr einloggen

## v2.0.0 – Versionierung & Antwort-Anzeige (2026-03-30)
- Versionshistorie im Admin-Panel (Admin → Version)
- CHANGELOG.md im Projektordner
- 💬 "Neue Antwort!" Anzeige im Nutzer-Portal wenn Admin geantwortet hat
- Changelog wird ab jetzt bei jeder Änderung aktualisiert

## v1.0.0 – Grundsystem (2026-03-28)
- Basis-Ticketsystem mit FastAPI + SQLite
- Nutzer-Registrierung mit E-Mail-Verifikation
- Login / Logout mit JWT-Session
- Tickets erstellen, kommentieren, schließen
- Admin-Panel mit Dashboard
- E-Mail-Benachrichtigungen (SMTP SSL Port 465)
- HTTPS via Nginx Proxy Manager + Let's Encrypt
- Dark/Light Mode
- Systemd-Service + automatische Backups

## v1.1.0 – Admin-Features (2026-03-28)
- Admin-Dashboard mit 5 Statistik-Kacheln
- Unbeantwortet-Übersicht
- Interne Admin-Notizen
- Änderungshistorie bei Tickets
- Nutzer verwalten (verifizieren, löschen)
- Passwort-Reset per E-Mail
- PDF-Export für Tickets

## v1.2.0 – UX & Design (2026-03-29)
- Mobile-Optimierung (responsive CSS)
- Favicon + Apple Touch Icon
- Barrierefreiheit (aria-label, Skip-Link, Fokus-Ringe)
- Ladeindikator bei Formular-Submit
- Zeichen-Counter in Textareas (max. 2000)
- Avatar/Initialen in Navigation
- Suchbegriff-Highlighting

## v1.3.0 – Sortierung & Suche (2026-03-29)
- Klickbare Spalten-Sortierung in Admin-Dashboard
- Klickbare Spalten-Sortierung in Nutzer-Liste
- Klickbare Spalten-Sortierung im Kunden-Portal
- Suchfunktion im Admin-Dashboard
- Suchfunktion in der Aufgabenliste
- Suchfunktion im Kunden-Portal

## v1.4.0 – Online-Nutzer & Sicherheit (2026-03-29)
- Online-Nutzer Anzeige im Admin-Dashboard (letzte 15 Min)
- Fail2Ban Integration (SSH + Ticketsystem)
- Admin-Sicherheitsseite mit Ban/Unban
- Rate Limiting auf Login (slowapi)
- Nutzer bearbeiten + Admin-Rechte vergeben

## v1.5.0 – Aufgabenverwaltung (2026-03-29)
- Admin-Aufgabenliste (intern, nicht für Nutzer sichtbar)
- Aufgaben erstellen, bearbeiten, erledigen, löschen
- Fälligkeitsdatum mit Überfällig-Warnung
- Änderungshistorie für Aufgaben
- Erinnerungs-E-Mail täglich um 7 Uhr
- Aufgaben-Widget im Admin-Dashboard

## v1.6.0 – Statistiken & Charts (2026-03-29)
- Reaktionszeit-Chart pro Monat
- Donut-Charts Tickets nach Status und Priorität
- Zahlen in der Mitte der Donut-Charts
- Prozentanzeige im Tooltip
- Reaktionszeit-Fix (keine 0-Werte mehr)

## v1.7.0 – Ticket-Features (2026-03-30)
- ★ Stern-Markierung für wichtige Tickets
- 🏷️ Tags (kommagetrennt, als farbige Badges)
- Ticket löschen (mit Bestätigung) im Admin-Panel
- Ticket-Zusammenfassung bei gelösten Tickets
- 🔴 "Wartet auf Antwort" Status im Dashboard
- ✓ "Beantwortet" Status im Dashboard
- Abgrenzung aktive / gelöste Tickets im Dashboard

## v1.8.0 – Profil & Registrierung (2026-03-30)
- Avatar-Upload (JPG/PNG/GIF, max. 2MB)
- Avatar in Navigation angezeigt
- Passwort 2x eingeben bei Registrierung
- Passwort-Stärke-Anzeige (live)
- Gemeinden-Dropdown bei Registrierung
- Funktion "Hauptamtlicher Gerätewart" hinzugefügt
- © Footer mit Torsten Michaely

## v1.9.0 – Rechtliches & Impressum (2026-03-30)
- Impressum (Landkreis Saarlouis als Auftraggeber)
- Datenschutzerklärung (DSGVO-konform)
- Kein Cookie-Banner (nur technisch notwendige Cookies)
- Statusseite (/status) mit Ampel-System
- 404-Fehlerseite

---

## Geplant / Roadmap
- [ ] Mehrsprachigkeit (DE/EN)
- [ ] E-Mail-Vorlagen anpassbar
- [ ] API-Dokumentation

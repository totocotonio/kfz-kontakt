from fastapi import FastAPI, Depends, HTTPException, status, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional, List
import uvicorn
import os
import shutil
import asyncio
import threading
import time
import secrets
from zoneinfo import ZoneInfo

BERLIN = ZoneInfo("Europe/Berlin")

def now_berlin():
    from datetime import timezone
    return datetime.now(timezone.utc).astimezone(BERLIN).replace(tzinfo=None)

from database import get_db, engine, Base
from models import User, Ticket, Comment, TicketAttachment, TicketStatus, TicketPriority, AdminNote, TicketHistory, PasswordResetToken, TicketSequence, AdminTask, TaskHistory
from auth import (
    authenticate_user, create_access_token, get_current_user,
    get_password_hash, ACCESS_TOKEN_EXPIRE_MINUTES
)
from email_utils import (send_ticket_created_email, send_ticket_updated_email,
                         send_new_registration_email, send_new_ticket_admin_email,
                         send_registration_confirmation_email, send_reminder_email,
                         send_user_comment_admin_email, send_password_reset_email,
                         send_verification_email, send_task_reminder_email,
                         send_daily_summary_email)
import schemas

Base.metadata.create_all(bind=engine)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI(title="MP-Feuer-Ticketsystem")
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return templates.TemplateResponse("404.html", {"request": request}, status_code=404)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ─── ERINNERUNGSMAIL HINTERGRUNDTASK ────────────────────────────
def reminder_task():
    """Läuft alle 24h, sendet Erinnerungen bei Tickets älter als 5 Tage."""
    while True:
        time.sleep(86400)  # 24 Stunden
        try:
            from database import SessionLocal
            db = SessionLocal()
            cutoff = datetime.utcnow() - timedelta(days=5)
            old_tickets = db.query(Ticket).filter(
                Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress]),
                Ticket.updated_at < cutoff
            ).all()
            for ticket in old_tickets:
                user = db.query(User).filter(User.id == ticket.user_id).first()
                if user:
                    send_reminder_email(user.email, user.name, ticket)
            db.close()
            print(f"[REMINDER] {len(old_tickets)} Erinnerungen gesendet")
        except Exception as e:
            print(f"[REMINDER FEHLER] {e}")

def task_reminder_task():
    """Läuft täglich um 7 Uhr und sendet Erinnerungen für fällige Aufgaben."""
    while True:
        now = now_berlin()
        # Warte bis 7 Uhr morgens
        target = now.replace(hour=7, minute=0, second=0, microsecond=0)
        if now >= target:
            target = target + timedelta(days=1)
        wait_seconds = (target - now).total_seconds()
        time.sleep(wait_seconds)
        try:
            from database import SessionLocal
            db = SessionLocal()
            today_start = now_berlin().replace(hour=0, minute=0, second=0)
            today_end = now_berlin().replace(hour=23, minute=59, second=59)
            due_tasks = db.query(AdminTask).filter(
                AdminTask.is_done == False,
                AdminTask.due_date >= today_start,
                AdminTask.due_date <= today_end
            ).all()
            if due_tasks:
                admins = db.query(User).filter(User.is_admin == True).all()
                for admin in admins:
                    send_task_reminder_email(admin.email, admin.name, due_tasks)
                print(f"[TASK REMINDER] {len(due_tasks)} fällige Aufgaben gesendet")
            db.close()
        except Exception as e:
            print(f"[TASK REMINDER FEHLER] {e}")

def daily_summary_task():
    """Sendet täglich um 7:30 Uhr eine Zusammenfassung an alle Admins."""
    while True:
        now = now_berlin()
        target = now.replace(hour=7, minute=30, second=0, microsecond=0)
        if now >= target:
            target = target + timedelta(days=1)
        time.sleep((target - now).total_seconds())
        try:
            from database import SessionLocal
            db = SessionLocal()
            today_start = now_berlin().replace(hour=0, minute=0, second=0)
            total = db.query(Ticket).count()
            open_t = db.query(Ticket).filter(Ticket.status == TicketStatus.open).count()
            in_progress = db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count()
            resolved_today = db.query(Ticket).filter(
                Ticket.resolved_at >= today_start).count()
            open_tasks = db.query(AdminTask).filter(AdminTask.is_done == False).count()
            # Unbeantwortet zählen
            tickets_active = db.query(Ticket).filter(
                Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress])).all()
            unanswered = 0
            for t in tickets_active:
                comments = db.query(Comment).filter(Comment.ticket_id == t.id)\
                             .order_by(Comment.created_at.desc()).first()
                if not comments or not comments.is_admin:
                    unanswered += 1
            stats = {
                "date": now_berlin().strftime('%d.%m.%Y'),
                "total": total, "open": open_t, "in_progress": in_progress,
                "unanswered": unanswered, "resolved_today": resolved_today,
                "open_tasks": open_tasks
            }
            admins = db.query(User).filter(User.is_admin == True).all()
            for admin in admins:
                send_daily_summary_email(admin.email, admin.name, stats)
            db.close()
            print(f"[DAILY SUMMARY] Gesendet an {len(admins)} Admin(s)")
        except Exception as e:
            print(f"[DAILY SUMMARY FEHLER] {e}")

@app.on_event("startup")
async def startup_event():
    # Prioritätsfarben als Jinja-Global setzen
    settings = load_settings()
    colors = settings.get("priority_colors", {
        "critical": "#ef4444", "high": "#f59e0b",
        "medium": "#3b82f6", "low": "#6b7280"
    })
    templates.env.globals["priority_colors"] = colors

    t = threading.Thread(target=reminder_task, daemon=True)
    t.start()
    t2 = threading.Thread(target=task_reminder_task, daemon=True)
    t2.start()
    t3 = threading.Thread(target=daily_summary_task, daemon=True)
    t3.start()
    print("[STARTUP] Erinnerungs-Tasks gestartet")

@app.middleware("http")
async def update_last_seen(request: Request, call_next):
    response = await call_next(request)
    try:
        token = request.cookies.get("access_token")
        if token:
            from database import SessionLocal
            from auth import jwt, SECRET_KEY, ALGORITHM
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            user_id = payload.get("sub")
            if user_id:
                db = SessionLocal()
                user = db.query(User).filter(User.id == int(user_id)).first()
                if user:
                    user.last_seen = now_berlin()
                    db.commit()
                db.close()
    except:
        pass
    return response

# ─── AUTH ROUTES ────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
@limiter.limit("5/minute")
async def login(request: Request, db: Session = Depends(get_db),
                email: str = Form(...), password: str = Form(...)):
    user = authenticate_user(db, email, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Ungültige E-Mail oder Passwort"
        })
    if not user.is_verified and not user.is_admin:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Bitte bestätigen Sie zuerst Ihre E-Mail-Adresse."
        })
    if hasattr(user, 'is_active') and user.is_active == False:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "Ihr Konto wurde deaktiviert. Bitte wenden Sie sich an den Administrator."
        })
    access_token = create_access_token(data={"sub": str(user.id)})
    if user.is_admin:
        response = RedirectResponse(url="/admin", status_code=302)
    else:
        response = RedirectResponse(url="/portal", status_code=302)
    response.set_cookie("access_token", access_token, httponly=True)
    return response

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie("access_token")
    return response

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(request: Request, db: Session = Depends(get_db),
                   name: str = Form(...), email: str = Form(...),
                   password: str = Form(...), password2: str = Form(...),
                   feuerwehr: str = Form(...),
                   loeschbezirk: str = Form(...), telefon: str = Form(...),
                   funktion: str = Form(...)):
    if password != password2:
        return templates.TemplateResponse("register.html", {
            "request": request, "error": "Die Passwörter stimmen nicht überein."
        })
    if len(password) < 8:
        return templates.TemplateResponse("register.html", {
            "request": request, "error": "Das Passwort muss mindestens 8 Zeichen lang sein."
        })
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        return templates.TemplateResponse("register.html", {
            "request": request, "error": "E-Mail bereits registriert"
        })
    user = User(name=name, email=email,
                hashed_password=get_password_hash(password),
                feuerwehr=feuerwehr, loeschbezirk=loeschbezirk,
                telefon=telefon, funktion=funktion,
                is_verified=False,
                verification_token=secrets.token_urlsafe(32))
    db.add(user)
    db.commit()
    db.refresh(user)
    send_new_registration_email(user)
    send_verification_email(user, user.verification_token)
    return RedirectResponse(url="/login?verify=1", status_code=302)

# ─── CUSTOMER PORTAL ────────────────────────────────────────────
@app.get("/portal", response_class=HTMLResponse)
async def portal(request: Request, db: Session = Depends(get_db),
                 sort: Optional[str] = "created_at",
                 order: Optional[str] = "desc",
                 search: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    sort_map = {
        "created_at": Ticket.created_at,
        "updated_at": Ticket.updated_at,
        "title": Ticket.title,
        "status": Ticket.status,
        "priority": Ticket.priority,
    }
    sort_col = sort_map.get(sort, Ticket.created_at)
    query = db.query(Ticket).filter(Ticket.user_id == user.id)
    if search:
        query = query.filter(
            Ticket.title.ilike(f"%{search}%") |
            Ticket.description.ilike(f"%{search}%")
        )
    if order == "asc":
        query = query.order_by(sort_col.asc())
    else:
        query = query.order_by(sort_col.desc())
    tickets = query.all()
    return templates.TemplateResponse("portal.html", {
        "request": request, "user": user, "tickets": tickets,
        "sort": sort, "order": order, "search": search or ""
    })

@app.get("/portal/new", response_class=HTMLResponse)
async def new_ticket_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("new_ticket.html", {
        "request": request, "user": user,
        "priorities": TicketPriority, "statuses": TicketStatus
    })

@app.post("/portal/new")
async def create_ticket(request: Request, db: Session = Depends(get_db),
                        title: str = Form(...), description: str = Form(...),
                        priority: str = Form(...),
                        files: List[UploadFile] = File(default=[])):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    # Fortlaufende Ticket-Nummer vergeben
    seq = db.query(TicketSequence).first()
    if not seq:
        seq = TicketSequence(last_number=0)
        db.add(seq)
        db.flush()
    seq.last_number += 1
    ticket = Ticket(
        title=title, description=description,
        priority=TicketPriority(priority),
        user_id=user.id,
        ticket_number_seq=seq.last_number
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    # Dateien speichern
    ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc', '.docx', '.txt', '.zip'}
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB
    for file in files:
        if file.filename:
            ext = os.path.splitext(file.filename)[1].lower()
            if ext not in ALLOWED_EXTENSIONS:
                continue  # Unerlaubte Dateitypen überspringen
            contents = await file.read()
            if len(contents) > MAX_FILE_SIZE:
                continue  # Zu große Dateien überspringen
            import re
            safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename)
            filename = f"ticket_{ticket.id}_{int(time.time())}_{safe_filename}"
            filepath = os.path.join(UPLOAD_DIR, filename)
            with open(filepath, "wb") as f:
                f.write(contents)
            attachment = TicketAttachment(
                filename=file.filename,
                filepath=filename,
                ticket_id=ticket.id
            )
            db.add(attachment)
    db.commit()
    send_ticket_created_email(user.email, user.name, ticket)
    send_new_ticket_admin_email(user, ticket)
    return RedirectResponse(url=f"/portal/ticket/{ticket.id}", status_code=302)

@app.get("/portal/ticket/{ticket_id}", response_class=HTMLResponse)
async def view_ticket(request: Request, ticket_id: int,
                      db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    # Als gelesen markieren wenn Nutzer Ticket öffnet
    if not ticket.last_admin_reply_read:
        ticket.last_admin_reply_read = True
        db.commit()
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.desc()).all()
    return templates.TemplateResponse("ticket_detail.html", {
        "request": request, "user": user,
        "ticket": ticket, "comments": comments
    })

@app.post("/portal/ticket/{ticket_id}/reopen")
async def reopen_ticket(request: Request, ticket_id: int,
                        db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    ticket.status = TicketStatus.open
    ticket.updated_at = now_berlin()
    ticket.last_user_activity = now_berlin()
    db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                         field="Status", old_value="closed/resolved",
                         new_value="open"))
    db.commit()
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

@app.post("/portal/ticket/{ticket_id}/close")
async def close_ticket_customer(request: Request, ticket_id: int,
                                db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    ticket.status = TicketStatus.closed
    ticket.updated_at = now_berlin()
    db.commit()
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

@app.post("/portal/ticket/{ticket_id}/comment")
async def add_comment_customer(request: Request, ticket_id: int,
                               db: Session = Depends(get_db),
                               content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=False)
    db.add(comment)
    ticket.last_user_activity = now_berlin()
    ticket.updated_at = now_berlin()
    db.commit()
    send_user_comment_admin_email(user, ticket, content)
    return RedirectResponse(url=f"/portal/ticket/{ticket_id}", status_code=302)

# ─── ADMIN PANEL ─────────────────────────────────────────────────
@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: Session = Depends(get_db),
                          status_filter: Optional[str] = None,
                          priority_filter: Optional[str] = None,
                          sort: Optional[str] = "created_at",
                          order: Optional[str] = "desc",
                          search: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    query = db.query(Ticket)
    if status_filter:
        query = query.filter(Ticket.status == TicketStatus(status_filter))
    if priority_filter:
        query = query.filter(Ticket.priority == TicketPriority(priority_filter))
    if search:
        query = query.join(User).filter(
            Ticket.title.ilike(f"%{search}%") |
            Ticket.description.ilike(f"%{search}%") |
            User.name.ilike(f"%{search}%") |
            User.feuerwehr.ilike(f"%{search}%")
        )
    # Sortierung
    sort_map = {
        "created_at": Ticket.created_at,
        "updated_at": Ticket.updated_at,
        "title": Ticket.title,
        "status": Ticket.status,
        "priority": Ticket.priority,
    }
    sort_col = sort_map.get(sort, Ticket.created_at)
    if order == "asc":
        query = query.order_by(sort_col.asc())
    else:
        query = query.order_by(sort_col.desc())
    tickets = query.all()
    tickets = query.order_by(Ticket.created_at.desc()).all()

    # Unbeantwortet: letzter Kommentar ist vom Nutzer (nicht Admin)
    all_tickets = db.query(Ticket).filter(
        Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress])
    ).all()
    unanswered = []
    for t in all_tickets:
        if t.comments:
            last_comment = sorted(t.comments, key=lambda c: c.created_at)[-1]
            if not last_comment.is_admin:
                unanswered.append(t)
        else:
            # Neues Ticket ohne Kommentare = immer unbeantwortet
            unanswered.append(t)

    # Online-Nutzer (aktiv in den letzten 15 Minuten)
    online_cutoff = now_berlin() - timedelta(minutes=15)
    online_users = db.query(User).filter(
        User.last_seen >= online_cutoff,
        User.is_admin == False
    ).order_by(User.last_seen.desc()).all()

    stats = {
        "total": db.query(Ticket).count(),
        "open": db.query(Ticket).filter(Ticket.status == TicketStatus.open).count(),
        "in_progress": db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count(),
        "resolved": db.query(Ticket).filter(Ticket.status == TicketStatus.resolved).count(),
        "unanswered": len(unanswered),
    }
    # Offene Aufgaben
    open_tasks = db.query(AdminTask).filter(AdminTask.is_done == False)\
                   .order_by(AdminTask.due_date.asc().nullslast()).limit(5).all()
    overdue_tasks_count = db.query(AdminTask).filter(
        AdminTask.is_done == False,
        AdminTask.due_date < now_berlin()
    ).count()

    return templates.TemplateResponse("admin_dashboard.html", {
        "request": request, "user": user, "tickets": tickets,
        "stats": stats, "statuses": TicketStatus, "priorities": TicketPriority,
        "status_filter": status_filter, "priority_filter": priority_filter,
        "unanswered_tickets": unanswered,
        "online_users": online_users,
        "sort": sort, "order": order,
        "open_tasks": open_tasks,
        "overdue_tasks_count": overdue_tasks_count,
        "now_berlin": now_berlin(),
        "search": search or ""
    })

@app.get("/admin/ticket/{ticket_id}", response_class=HTMLResponse)
async def admin_view_ticket(request: Request, ticket_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.desc()).all()
    return templates.TemplateResponse("admin_ticket.html", {
        "request": request, "user": user, "ticket": ticket,
        "comments": comments, "statuses": TicketStatus, "priorities": TicketPriority
    })

@app.post("/admin/ticket/{ticket_id}/star")
async def toggle_star(request: Request, ticket_id: int, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if ticket:
        ticket.is_starred = not ticket.is_starred
        db.commit()
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/admin/ticket/{ticket_id}/tags")
async def update_tags(request: Request, ticket_id: int, db: Session = Depends(get_db),
                      tags: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if ticket:
        ticket.tags = tags.strip()
        db.commit()
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/portal/profil/avatar")
async def upload_avatar(request: Request, db: Session = Depends(get_db),
                        avatar: UploadFile = File(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    if avatar.filename:
        ext = os.path.splitext(avatar.filename)[1].lower()
        if ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
            contents = await avatar.read()
            if len(contents) <= 2 * 1024 * 1024:  # Max 2MB
                import re
                filename = f"avatar_{user.id}{ext}"
                filepath = os.path.join(UPLOAD_DIR, filename)
                with open(filepath, "wb") as f:
                    f.write(contents)
                user.avatar = filename
                db.commit()
    return RedirectResponse(url="/portal/profil?success=1", status_code=302)

@app.post("/admin/ticket/{ticket_id}/delete")
async def admin_delete_ticket(request: Request, ticket_id: int,
                              db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    db.query(Comment).filter(Comment.ticket_id == ticket_id).delete()
    db.query(TicketHistory).filter(TicketHistory.ticket_id == ticket_id).delete()
    db.query(AdminNote).filter(AdminNote.ticket_id == ticket_id).delete()
    db.query(TicketAttachment).filter(TicketAttachment.ticket_id == ticket_id).delete()
    db.delete(ticket)
    db.commit()
    return RedirectResponse(url="/admin", status_code=302)

@app.post("/admin/ticket/{ticket_id}/update")
async def admin_update_ticket(request: Request, ticket_id: int,
                              db: Session = Depends(get_db),
                              status: str = Form(...),
                              priority: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    old_status = ticket.status
    old_priority = ticket.priority
    ticket.status = TicketStatus(status)
    ticket.priority = TicketPriority(priority)
    ticket.updated_at = now_berlin()
    ticket.last_user_activity = now_berlin()  # Zeitstempel in Aktivität-Spalte
    # Lösungszeit erfassen
    if ticket.status == TicketStatus.resolved and old_status != TicketStatus.resolved:
        ticket.resolved_at = now_berlin()
        if not ticket.first_response_at:
            ticket.first_response_at = now_berlin()  # Falls noch keine Antwort
    # History aufzeichnen
    if old_status != ticket.status:
        db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                             field="Status", old_value=old_status.value,
                             new_value=ticket.status.value))
    if old_priority != ticket.priority:
        db.add(TicketHistory(ticket_id=ticket_id, changed_by_id=user.id,
                             field="Priorität", old_value=old_priority.value,
                             new_value=ticket.priority.value))
    db.commit()
    if old_status != ticket.status:
        customer = db.query(User).filter(User.id == ticket.user_id).first()
        if customer:
            send_ticket_updated_email(customer.email, customer.name, ticket)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.post("/admin/ticket/{ticket_id}/comment")
async def admin_add_comment(request: Request, ticket_id: int,
                            db: Session = Depends(get_db),
                            content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comment = Comment(content=content, ticket_id=ticket_id,
                      user_id=user.id, is_admin=True)
    db.add(comment)
    # Erste Reaktionszeit erfassen
    if not ticket.first_response_at:
        ticket.first_response_at = now_berlin()
    ticket.updated_at = now_berlin()
    ticket.last_admin_reply_read = False  # Nutzer hat noch nicht gelesen
    db.commit()
    customer = db.query(User).filter(User.id == ticket.user_id).first()
    if customer:
        send_ticket_updated_email(customer.email, customer.name, ticket,
                                  comment_added=True, comment_content=content,
                                  sachbearbeiter=user.name)
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

@app.get("/admin/users/{user_id}/edit", response_class=HTMLResponse)
async def admin_edit_user_page(request: Request, user_id: int,
                               db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    edit_user = db.query(User).filter(User.id == user_id).first()
    if not edit_user:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("admin_edit_user.html", {
        "request": request, "user": user, "edit_user": edit_user
    })

@app.post("/admin/users/{user_id}/edit")
async def admin_edit_user(request: Request, user_id: int,
                          db: Session = Depends(get_db),
                          name: str = Form(...), email: str = Form(...),
                          telefon: str = Form(default=""),
                          feuerwehr: str = Form(default=""),
                          loeschbezirk: str = Form(default=""),
                          funktion: str = Form(default=""),
                          is_admin: str = Form(default=""),
                          is_verified: str = Form(default=""),
                          password: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    edit_user = db.query(User).filter(User.id == user_id).first()
    if not edit_user:
        raise HTTPException(status_code=404)
    edit_user.name = name
    edit_user.email = email
    edit_user.telefon = telefon
    edit_user.feuerwehr = feuerwehr
    edit_user.loeschbezirk = loeschbezirk
    edit_user.funktion = funktion
    edit_user.is_admin = bool(is_admin)
    edit_user.is_verified = bool(is_verified)
    if password:
        edit_user.hashed_password = get_password_hash(password)
    db.commit()
    return templates.TemplateResponse("admin_edit_user.html", {
        "request": request, "user": user, "edit_user": edit_user,
        "success": "Nutzer erfolgreich gespeichert!"
    })

@app.post("/admin/users/{user_id}/toggle-active")
async def admin_toggle_active(request: Request, user_id: int,
                              db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    target = db.query(User).filter(User.id == user_id).first()
    if target and not target.is_admin:
        target.is_active = not getattr(target, 'is_active', True)
        db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)

@app.get("/admin/bulk-mail", response_class=HTMLResponse)
async def admin_bulk_mail_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    users = db.query(User).filter(User.is_verified == True).all()
    return templates.TemplateResponse("admin_bulk_mail.html", {
        "request": request, "user": user, "users": users
    })

@app.post("/admin/bulk-mail")
async def admin_bulk_mail_send(request: Request, db: Session = Depends(get_db),
                               subject: str = Form(...),
                               message: str = Form(...),
                               recipients: str = Form(default="all")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    if recipients == "all":
        users = db.query(User).filter(User.is_verified == True, User.is_admin == False).all()
    else:
        users = db.query(User).filter(User.feuerwehr == recipients, User.is_verified == True).all()
    sent = 0
    for u in users:
        try:
            from email_utils import _send, APP_URL
            html = f"""<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;">
              <h2 style="color:#3b82f6;">📢 Mitteilung vom Admin</h2>
              <p>Hallo {u.name},</p>
              <div style="background:#f1f5f9;padding:16px;border-radius:8px;margin:16px 0;white-space:pre-line;">{message}</div>
              <p style="font-size:0.85rem;color:#666;">Gesendet von: {user.name} · MP-Feuer-Ticketsystem</p>
              <a href="{APP_URL}/portal" style="display:inline-block;padding:10px 20px;background:#3b82f6;color:#fff;text-decoration:none;border-radius:6px;">Portal öffnen</a>
            </div>"""
            _send(u.email, subject, html)
            sent += 1
        except:
            pass
    return templates.TemplateResponse("admin_bulk_mail.html", {
        "request": request, "user": user,
        "users": db.query(User).filter(User.is_verified == True).all(),
        "success": f"E-Mail erfolgreich an {sent} Nutzer gesendet!"
    })

@app.post("/admin/users/{user_id}/verify")
async def admin_verify_user(request: Request, user_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404)
    target.is_verified = True
    target.verification_token = None
    db.commit()
    send_registration_confirmation_email(target)
    return RedirectResponse(url="/admin/users", status_code=302)

@app.post("/admin/users/{user_id}/delete")
async def admin_delete_user(request: Request, user_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    target = db.query(User).filter(User.id == user_id).first()
    if not target or target.is_admin:
        raise HTTPException(status_code=403, detail="Nicht erlaubt")
    # Kommentare und Tickets des Nutzers auch löschen
    for ticket in target.tickets:
        db.query(Comment).filter(Comment.ticket_id == ticket.id).delete()
    db.query(Ticket).filter(Ticket.user_id == user_id).delete()
    db.query(Comment).filter(Comment.user_id == user_id).delete()
    db.delete(target)
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, db: Session = Depends(get_db),
                      sort: Optional[str] = "created_at",
                      order: Optional[str] = "desc"):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    sort_map = {
        "name": User.name,
        "email": User.email,
        "feuerwehr": User.feuerwehr,
        "created_at": User.created_at,
    }
    sort_col = sort_map.get(sort, User.created_at)
    if order == "asc":
        users = db.query(User).order_by(sort_col.asc()).all()
    else:
        users = db.query(User).order_by(sort_col.desc()).all()
    return templates.TemplateResponse("admin_users.html", {
        "request": request, "user": user, "users": users,
        "sort": sort, "order": order
    })

@app.get("/admin/stats", response_class=HTMLResponse)
async def admin_stats(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    from sqlalchemy import func
    # Tickets pro Status
    status_counts = {s.value: db.query(Ticket).filter(Ticket.status == s).count() for s in TicketStatus}
    # Tickets pro Priorität
    priority_counts = {p.value: db.query(Ticket).filter(Ticket.priority == p).count() for p in TicketPriority}
    # Tickets pro Tag (letzte 30 Tage)
    tickets_per_day = []
    for i in range(29, -1, -1):
        day = datetime.utcnow() - timedelta(days=i)
        day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day.replace(hour=23, minute=59, second=59)
        count = db.query(Ticket).filter(
            Ticket.created_at >= day_start,
            Ticket.created_at <= day_end
        ).count()
        tickets_per_day.append({"date": day.strftime("%d.%m"), "count": count})
    # Überfällige Tickets (älter als 5 Tage, noch offen)
    cutoff = datetime.utcnow() - timedelta(days=5)
    overdue = db.query(Ticket).filter(
        Ticket.status.in_([TicketStatus.open, TicketStatus.in_progress]),
        Ticket.updated_at < cutoff
    ).count()
    total = db.query(Ticket).count()
    users_count = db.query(User).filter(User.is_admin == False).count()

    # Reaktionszeiten berechnen
    tickets_with_response = db.query(Ticket).filter(
        Ticket.first_response_at != None
    ).all()
    tickets_resolved = db.query(Ticket).filter(
        Ticket.resolved_at != None
    ).all()

    avg_response_hours = None
    avg_resolve_hours = None
    if tickets_with_response:
        total_hours = sum(
            (t.first_response_at - t.created_at).total_seconds() / 3600
            for t in tickets_with_response
            if t.first_response_at and t.created_at and t.first_response_at > t.created_at
        )
        count = len([t for t in tickets_with_response if t.first_response_at and t.created_at and t.first_response_at > t.created_at])
        if count > 0:
            avg_response_hours = round(total_hours / count, 1)
    if tickets_resolved:
        total_hours = sum(
            (t.resolved_at - t.created_at).total_seconds() / 3600
            for t in tickets_resolved
            if t.resolved_at and t.created_at and t.resolved_at > t.created_at
        )
        count = len([t for t in tickets_resolved if t.resolved_at and t.created_at and t.resolved_at > t.created_at])
        if count > 0:
            avg_resolve_hours = round(total_hours / count, 1)

    # Reaktionszeiten pro Monat (letzte 6 Monate)
    monthly_stats = []
    for i in range(5, -1, -1):
        from datetime import timezone
        month_start = (datetime.now() - timedelta(days=i*30)).replace(day=1, hour=0, minute=0, second=0)
        month_end = (month_start + timedelta(days=32)).replace(day=1)
        month_tickets = db.query(Ticket).filter(
            Ticket.created_at >= month_start,
            Ticket.created_at < month_end,
            Ticket.first_response_at != None
        ).all()
        if month_tickets:
            avg = sum((t.first_response_at - t.created_at).total_seconds() / 3600 for t in month_tickets) / len(month_tickets)
        else:
            avg = 0
        monthly_stats.append({
            "month": month_start.strftime("%b %Y"),
            "avg_hours": round(avg, 1),
            "count": len(month_tickets)
        })
    # Tickets pro Gemeinde
    gemeinden = ['Dillingen','Lebach','Saarlouis','Bous','Ensdorf','Nalbach',
                 'Rehlingen-Siersburg','Saarwellingen','Schmelz','Schwalbach',
                 'Wadgassen','Wallerfangen','Überherrn']
    gemeinde_stats = []
    for g in gemeinden:
        count = db.query(Ticket).join(User).filter(User.feuerwehr == g).count()
        if count > 0:
            gemeinde_stats.append({"name": g, "count": count})
    gemeinde_stats.sort(key=lambda x: x["count"], reverse=True)

    return templates.TemplateResponse("admin_stats.html", {
        "request": request, "user": user,
        "status_counts": status_counts,
        "priority_counts": priority_counts,
        "tickets_per_day": tickets_per_day,
        "overdue": overdue, "total": total,
        "users_count": users_count,
        "avg_response_hours": avg_response_hours,
        "avg_resolve_hours": avg_resolve_hours,
        "monthly_stats": monthly_stats,
        "gemeinde_stats": gemeinde_stats,
    })

# ─── PASSWORT VERGESSEN ──────────────────────────────────────────
@app.get("/impressum", response_class=HTMLResponse)
async def impressum(request: Request):
    user = None
    try:
        from database import SessionLocal
        db = SessionLocal()
        user = await get_current_user(request, db)
        db.close()
    except:
        pass
    return templates.TemplateResponse("impressum.html", {"request": request, "user": user})

@app.get("/datenschutz", response_class=HTMLResponse)
async def datenschutz(request: Request):
    user = None
    try:
        from database import SessionLocal
        db = SessionLocal()
        user = await get_current_user(request, db)
        db.close()
    except:
        pass
    return templates.TemplateResponse("datenschutz.html", {"request": request, "user": user})

# ─── E-MAIL VERIFIKATION ────────────────────────────────────────
@app.get("/verify-email/{token}", response_class=HTMLResponse)
async def verify_email(request: Request, token: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.verification_token == token).first()
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Ungültiger oder abgelaufener Bestätigungslink."
        })
    user.is_verified = True
    user.verification_token = None
    db.commit()
    send_registration_confirmation_email(user)
    return RedirectResponse(url="/login?registered=1", status_code=302)

@app.get("/forgot-password", response_class=HTMLResponse)
async def forgot_password_page(request: Request):
    return templates.TemplateResponse("forgot_password.html", {"request": request})

@app.post("/forgot-password")
async def forgot_password(request: Request, db: Session = Depends(get_db),
                          email: str = Form(...)):
    user = db.query(User).filter(User.email == email).first()
    if user:
        token = secrets.token_urlsafe(32)
        reset = PasswordResetToken(
            token=token, user_id=user.id,
            expires_at=now_berlin() + timedelta(hours=2)
        )
        db.add(reset)
        db.commit()
        send_password_reset_email(user.email, user.name, token)
    return templates.TemplateResponse("forgot_password.html", {
        "request": request,
        "success": "Falls die E-Mail registriert ist, wurde ein Reset-Link gesendet."
    })

@app.get("/reset-password/{token}", response_class=HTMLResponse)
async def reset_password_page(request: Request, token: str, db: Session = Depends(get_db)):
    reset = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > now_berlin()
    ).first()
    if not reset:
        return templates.TemplateResponse("reset_password.html", {
            "request": request, "error": "Link ungültig oder abgelaufen."
        })
    return templates.TemplateResponse("reset_password.html", {
        "request": request, "token": token
    })

@app.post("/reset-password/{token}")
async def reset_password(request: Request, token: str, db: Session = Depends(get_db),
                         password: str = Form(...)):
    reset = db.query(PasswordResetToken).filter(
        PasswordResetToken.token == token,
        PasswordResetToken.used == False,
        PasswordResetToken.expires_at > now_berlin()
    ).first()
    if not reset:
        return templates.TemplateResponse("reset_password.html", {
            "request": request, "error": "Link ungültig oder abgelaufen."
        })
    user = db.query(User).filter(User.id == reset.user_id).first()
    user.hashed_password = get_password_hash(password)
    reset.used = True
    db.commit()
    return RedirectResponse(url="/login?reset=1", status_code=302)

# ─── PROFIL BEARBEITEN ───────────────────────────────────────────
@app.get("/portal/profil", response_class=HTMLResponse)
async def profil_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    return templates.TemplateResponse("profil.html", {"request": request, "user": user})

@app.post("/portal/profil")
async def profil_update(request: Request, db: Session = Depends(get_db),
                        name: str = Form(...), telefon: str = Form(...),
                        funktion: str = Form(...), feuerwehr: str = Form(...),
                        loeschbezirk: str = Form(...),
                        password: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    user.name = name
    user.telefon = telefon
    user.funktion = funktion
    user.feuerwehr = feuerwehr
    user.loeschbezirk = loeschbezirk
    if password:
        user.hashed_password = get_password_hash(password)
    db.commit()
    return templates.TemplateResponse("profil.html", {
        "request": request, "user": user,
        "success": "Profil erfolgreich gespeichert!"
    })

# ─── ADMIN NOTIZEN ───────────────────────────────────────────────
@app.post("/admin/ticket/{ticket_id}/note")
async def admin_add_note(request: Request, ticket_id: int,
                         db: Session = Depends(get_db),
                         content: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    note = AdminNote(content=content, ticket_id=ticket_id, admin_id=user.id)
    db.add(note)
    db.commit()
    return RedirectResponse(url=f"/admin/ticket/{ticket_id}", status_code=302)

# ─── PDF EXPORT ─────────────────────────────────────────────────
@app.get("/portal/ticket/{ticket_id}/pdf")
async def ticket_pdf_customer(request: Request, ticket_id: int,
                               db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id, Ticket.user_id == user.id
    ).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return _generate_ticket_pdf(ticket, comments)

@app.get("/admin/ticket/{ticket_id}/pdf")
async def ticket_pdf_admin(request: Request, ticket_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404)
    comments = db.query(Comment).filter(Comment.ticket_id == ticket_id)\
                 .order_by(Comment.created_at.asc()).all()
    return _generate_ticket_pdf(ticket, comments)

def _generate_ticket_pdf(ticket, comments):
    from fastapi.responses import Response
    comments_html = ""
    for c in comments:
        bg = "#e8f0fe" if c.is_admin else "#f5f5f5"
        author = f"Support-Team ({c.user.name})" if c.is_admin else f"{c.user.name}"
        comments_html += f"""
        <div style="background:{bg};border-left:4px solid {'#2563eb' if c.is_admin else '#ccc'};
                    padding:10px;margin:8px 0;border-radius:4px;">
          <div style="font-size:11px;color:#666;margin-bottom:4px;">
            {author} &middot; {c.created_at.strftime('%d.%m.%Y %H:%M')}
          </div>
          <p style="margin:0;">{c.content}</p>
        </div>"""
    html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body {{ font-family: Arial, sans-serif; font-size: 13px; color: #333; margin: 40px; }}
  h1 {{ color: #2563eb; font-size: 20px; margin:0; }}
  .header {{ border-bottom: 2px solid #2563eb; padding-bottom: 10px; margin-bottom: 20px; }}
  table {{ width: 100%; border-collapse: collapse; margin: 16px 0; }}
  td {{ padding: 8px; border-bottom: 1px solid #eee; }}
  td:first-child {{ font-weight: bold; width: 150px; background: #f8f9fa; }}
  .description {{ background: #f8f9fa; padding: 12px; border-radius: 4px; margin: 16px 0; white-space: pre-wrap; }}
  .footer {{ margin-top: 30px; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }}
</style>
</head><body>
<div class="header">
  <h1>MP-Feuer-Ticketsystem - Landkreis Saarlouis</h1>
  <h2 style="margin:4px 0;font-size:16px;">{ticket.ticket_number}: {ticket.title}</h2>
</div>
<table>
  <tr><td>Ticket-Nr.</td><td>{ticket.ticket_number}</td></tr>
  <tr><td>Status</td><td>{ticket.status_label}</td></tr>
  <tr><td>Prioritaet</td><td>{ticket.priority_label}</td></tr>
  <tr><td>Erstellt von</td><td>{ticket.user.name} ({ticket.user.email})</td></tr>
  <tr><td>Feuerwehr</td><td>{ticket.user.feuerwehr or '-'}</td></tr>
  <tr><td>Loeschbezirk</td><td>{ticket.user.loeschbezirk or '-'}</td></tr>
  <tr><td>Funktion</td><td>{ticket.user.funktion or '-'}</td></tr>
  <tr><td>Erstellt am</td><td>{ticket.created_at.strftime('%d.%m.%Y %H:%M')}</td></tr>
  <tr><td>Zuletzt geaendert</td><td>{ticket.updated_at.strftime('%d.%m.%Y %H:%M')}</td></tr>
</table>
<h3>Beschreibung</h3>
<div class="description">{ticket.description}</div>
<h3>Kommunikation ({len(comments)} Nachrichten)</h3>
{comments_html}
<div class="footer">Gedruckt am {datetime.now().strftime('%d.%m.%Y %H:%M')} - MP-Feuer-Ticketsystem des Landkreises Saarlouis</div>
</body></html>"""
    try:
        import weasyprint
        pdf = weasyprint.HTML(string=html).write_pdf()
        from fastapi.responses import Response
        return Response(content=pdf, media_type="application/pdf",
                       headers={"Content-Disposition": f"attachment; filename={ticket.ticket_number}.pdf"})
    except ImportError:
        from fastapi.responses import Response
        return Response(content=html + "<script>window.print()</script>",
                       media_type="text/html")

# ─── OEFFENTLICHE STATUSSEITE ────────────────────────────────────
@app.get("/status", response_class=HTMLResponse)
async def public_status(request: Request, db: Session = Depends(get_db)):
    stats = {
        "open": db.query(Ticket).filter(Ticket.status == TicketStatus.open).count(),
        "in_progress": db.query(Ticket).filter(Ticket.status == TicketStatus.in_progress).count(),
        "resolved": db.query(Ticket).filter(Ticket.status == TicketStatus.resolved).count(),
        "total": db.query(Ticket).count(),
    }
    return templates.TemplateResponse("public_status.html", {
        "request": request, "stats": stats
    })


@app.get("/admin/changelog", response_class=HTMLResponse)
async def admin_changelog(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    versions = [
        {"version": "v2.3.0", "date": "30.03.2026", "title": "Startseite & Einstellungen",
         "changes": ["🏠 Attraktive neue Startseite mit Hero-Design",
                     "🎨 Prioritätsfarben individuell anpassbar",
                     "⚙️ Einstellungsseite im Admin-Panel",
                     "Einstellungen im ⚙ Mehr Dropdown"]},
        {"version": "v2.2.0", "date": "30.03.2026", "title": "E-Mail-Vorschau & Druckansicht",
         "changes": ["👁 E-Mail-Vorschau vor dem Senden",
                     "🖨 Drucken-Button im Ticket-Detail",
                     "Optimierte Druckansicht (Navigation ausgeblendet)",
                     "Saubere Darstellung beim Drucken"]},
        {"version": "v2.1.0", "date": "30.03.2026", "title": "Nutzer & Kommunikation",
         "changes": ["💬 Neue Antwort als gelesen markieren",
                     "📊 Tägliche Zusammenfassung per E-Mail um 7:30 Uhr",
                     "🚒 Statistik Tickets pro Gemeinde",
                     "📢 Massenmail an alle oder einzelne Gemeinden",
                     "⏸ Nutzer deaktivieren/sperren statt nur löschen"]},
        {"version": "v2.0.0", "date": "30.03.2026", "title": "Versionierung & Antwort-Anzeige",
         "changes": ["Versionshistorie im Admin-Panel",
                     "CHANGELOG.md im Projektordner",
                     "💬 Neue Antwort! Anzeige im Nutzer-Portal",
                     "Changelog wird bei jeder Änderung aktualisiert"]},
        {"version": "v1.9.0", "date": "30.03.2026", "title": "Profil & Registrierung",
         "changes": ["Avatar-Upload (JPG/PNG/GIF, max. 2MB)", "Avatar in Navigation angezeigt",
                     "Passwort 2x eingeben bei Registrierung", "Passwort-Stärke-Anzeige (live)",
                     "Gemeinden-Dropdown bei Registrierung", "Funktion: Hauptamtlicher Gerätewart",
                     "© Footer mit Torsten Michaely"]},
        {"version": "v1.8.0", "date": "30.03.2026", "title": "Ticket-Features",
         "changes": ["★ Stern-Markierung für wichtige Tickets", "🏷️ Tags als farbige Badges",
                     "Ticket löschen mit Bestätigung", "Ticket-Zusammenfassung bei gelösten Tickets",
                     "🔴 Wartet auf Antwort / ✓ Beantwortet Status im Dashboard",
                     "Abgrenzung aktive / gelöste Tickets im Dashboard"]},
        {"version": "v1.7.0", "date": "29.03.2026", "title": "Statistiken & Charts",
         "changes": ["Reaktionszeit-Chart pro Monat", "Donut-Charts nach Status und Priorität",
                     "Zahlen + Prozent in Charts", "Reaktionszeit-Fix (keine 0-Werte)"]},
        {"version": "v1.6.0", "date": "29.03.2026", "title": "Aufgabenverwaltung",
         "changes": ["Admin-Aufgabenliste (intern)", "Aufgaben erstellen, bearbeiten, erledigen",
                     "Fälligkeitsdatum mit Überfällig-Warnung", "Änderungshistorie für Aufgaben",
                     "Erinnerungs-E-Mail täglich um 7 Uhr", "Aufgaben-Widget im Dashboard"]},
        {"version": "v1.5.0", "date": "29.03.2026", "title": "Sicherheit & Nutzerverwaltung",
         "changes": ["Online-Nutzer Anzeige (letzte 15 Min)", "Fail2Ban Integration",
                     "Admin-Sicherheitsseite mit Ban/Unban", "Nutzer bearbeiten + Admin-Rechte"]},
        {"version": "v1.4.0", "date": "29.03.2026", "title": "Sortierung & Suche",
         "changes": ["Klickbare Spalten-Sortierung überall", "Suchfunktion im Dashboard",
                     "Suchfunktion in Aufgaben und Portal", "Suchbegriff-Highlighting"]},
        {"version": "v1.3.0", "date": "29.03.2026", "title": "UX & Design",
         "changes": ["Mobile-Optimierung", "Favicon + Barrierefreiheit",
                     "Ladeindikator + Zeichen-Counter", "Dark/Light Mode verbessert"]},
        {"version": "v1.0.0", "date": "28.03.2026", "title": "Grundsystem",
         "changes": ["FastAPI + SQLite + Jinja2", "Registrierung mit E-Mail-Verifikation",
                     "Admin-Panel + E-Mail-Benachrichtigungen", "HTTPS + Systemd-Service + Backups"]},
    ]
    return templates.TemplateResponse("admin_changelog.html", {
        "request": request, "user": user, "versions": versions
    })

import json

SETTINGS_FILE = "/opt/ticketsystem/settings.json"

def load_settings():
    try:
        with open(SETTINGS_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_settings(data: dict):
    try:
        current = load_settings()
        current.update(data)
        with open(SETTINGS_FILE, "w") as f:
            json.dump(current, f)
    except:
        pass

@app.get("/admin/settings", response_class=HTMLResponse)
async def admin_settings_page(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    settings = load_settings()
    colors = settings.get("priority_colors", {})
    return templates.TemplateResponse("admin_settings.html", {
        "request": request, "user": user, "colors": colors
    })

@app.post("/admin/settings/colors")
async def admin_settings_colors(request: Request, db: Session = Depends(get_db),
                                color_critical: str = Form(default="#ef4444"),
                                color_high: str = Form(default="#f59e0b"),
                                color_medium: str = Form(default="#3b82f6"),
                                color_low: str = Form(default="#6b7280"),
                                color_critical_hex: str = Form(default=""),
                                color_high_hex: str = Form(default=""),
                                color_medium_hex: str = Form(default=""),
                                color_low_hex: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    colors = {
        "critical": color_critical_hex or color_critical,
        "high": color_high_hex or color_high,
        "medium": color_medium_hex or color_medium,
        "low": color_low_hex or color_low,
    }
    save_settings({"priority_colors": colors})
    templates.env.globals["priority_colors"] = colors
    return templates.TemplateResponse("admin_settings.html", {
        "request": request, "user": user,
        "colors": colors, "success": "Farben gespeichert!"
    })

# ─── ADMIN AUFGABEN ─────────────────────────────────────────────
@app.get("/admin/tasks", response_class=HTMLResponse)
async def admin_tasks(request: Request, db: Session = Depends(get_db),
                      search: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    query_open = db.query(AdminTask).filter(AdminTask.is_done == False)
    query_done = db.query(AdminTask).filter(AdminTask.is_done == True)
    if search:
        query_open = query_open.filter(
            AdminTask.title.ilike(f"%{search}%") |
            AdminTask.description.ilike(f"%{search}%")
        )
        query_done = query_done.filter(
            AdminTask.title.ilike(f"%{search}%") |
            AdminTask.description.ilike(f"%{search}%")
        )
    tasks_open = query_open.order_by(AdminTask.due_date.asc().nullslast(), AdminTask.created_at.desc()).all()
    tasks_done = query_done.order_by(AdminTask.done_at.desc()).limit(10).all()
    tasks_done_count = db.query(AdminTask).filter(AdminTask.is_done == True).count()
    return templates.TemplateResponse("admin_tasks.html", {
        "request": request, "user": user,
        "tasks_open": tasks_open, "tasks_done": tasks_done,
        "tasks_done_count": tasks_done_count,
        "priorities": TicketPriority, "now": now_berlin(),
        "search": search or ""
    })

@app.get("/admin/tasks/{task_id}/edit", response_class=HTMLResponse)
async def admin_task_edit_page(request: Request, task_id: int,
                               db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    task = db.query(AdminTask).filter(AdminTask.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("admin_task_edit.html", {
        "request": request, "user": user, "task": task
    })

@app.post("/admin/tasks/{task_id}/edit")
async def admin_task_edit(request: Request, task_id: int,
                          db: Session = Depends(get_db),
                          title: str = Form(...),
                          description: str = Form(default=""),
                          priority: str = Form(...),
                          due_date: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    task = db.query(AdminTask).filter(AdminTask.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404)

    # Alte Werte VOR der Änderung speichern
    old_title = task.title
    old_desc = task.description or ""
    old_prio = task.priority.value
    old_due = task.due_date.strftime('%d.%m.%Y') if task.due_date else "–"

    task.title = title
    task.description = description
    task.priority = TicketPriority(priority)
    task.updated_at = now_berlin()
    task.updated_by_id = user.id

    # Änderungen aufzeichnen
    if old_title != title:
        db.add(TaskHistory(task_id=task_id, changed_by_id=user.id,
                           field="Titel", old_value=old_title, new_value=title))
    if old_desc != (description or ""):
        db.add(TaskHistory(task_id=task_id, changed_by_id=user.id,
                           field="Beschreibung", old_value=old_desc[:100], new_value=(description or "")[:100]))
    if old_prio != priority:
        db.add(TaskHistory(task_id=task_id, changed_by_id=user.id,
                           field="Priorität", old_value=old_prio, new_value=priority))
    new_due = datetime.strptime(due_date, "%Y-%m-%d").strftime('%d.%m.%Y') if due_date else "–"
    if old_due != new_due:
        db.add(TaskHistory(task_id=task_id, changed_by_id=user.id,
                           field="Fälligkeitsdatum", old_value=old_due, new_value=new_due))

    if due_date:
        try:
            task.due_date = datetime.strptime(due_date, "%Y-%m-%d")
        except:
            pass
    else:
        task.due_date = None
    db.commit()
    return RedirectResponse(url="/admin/tasks", status_code=302)

@app.post("/admin/tasks/new")
async def admin_task_new(request: Request, db: Session = Depends(get_db),
                         title: str = Form(...), description: str = Form(default=""),
                         priority: str = Form(...), due_date: str = Form(default="")):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    due = None
    if due_date:
        try:
            from datetime import datetime
            due = datetime.strptime(due_date, "%Y-%m-%d")
        except:
            pass
    task = AdminTask(title=title, description=description,
                     priority=TicketPriority(priority),
                     due_date=due, created_by_id=user.id)
    db.add(task)
    db.commit()
    return RedirectResponse(url="/admin/tasks", status_code=302)

@app.post("/admin/tasks/{task_id}/done")
async def admin_task_done(request: Request, task_id: int,
                          db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    task = db.query(AdminTask).filter(AdminTask.id == task_id).first()
    if task:
        task.is_done = True
        task.done_at = now_berlin()
        db.add(TaskHistory(task_id=task.id, changed_by_id=user.id,
                           field="Status", old_value="Offen", new_value="Erledigt"))
        db.commit()
    return RedirectResponse(url="/admin/tasks", status_code=302)

@app.post("/admin/tasks/{task_id}/reopen")
async def admin_task_reopen(request: Request, task_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    task = db.query(AdminTask).filter(AdminTask.id == task_id).first()
    if task:
        task.is_done = False
        task.done_at = None
        db.add(TaskHistory(task_id=task.id, changed_by_id=user.id,
                           field="Status", old_value="Erledigt", new_value="Wieder geöffnet"))
        db.commit()
    return RedirectResponse(url="/admin/tasks", status_code=302)

@app.post("/admin/tasks/{task_id}/delete")
async def admin_task_delete(request: Request, task_id: int,
                            db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    task = db.query(AdminTask).filter(AdminTask.id == task_id).first()
    if task:
        db.delete(task)
        db.commit()
    return RedirectResponse(url="/admin/tasks", status_code=302)

# ─── SICHERHEIT / FAIL2BAN ──────────────────────────────────────
def _f2b_command(args: list):
    import subprocess
    try:
        result = subprocess.run(
            ["fail2ban-client"] + args,
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip(), result.returncode == 0
    except Exception as e:
        return str(e), False

def _get_banned_ips():
    banned = []
    for jail in ["sshd", "ticketsystem"]:
        output, ok = _f2b_command(["status", jail])
        if ok and "Banned IP list:" in output:
            for line in output.split("\n"):
                if "Banned IP list:" in line:
                    ips = line.split("Banned IP list:")[1].strip().split()
                    for ip in ips:
                        if ip:
                            banned.append({"ip": ip, "jail": jail, "time": "–"})
    return banned

@app.get("/admin/security", response_class=HTMLResponse)
async def admin_security(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    banned_ips = _get_banned_ips()
    ssh_bans = sum(1 for b in banned_ips if b["jail"] == "sshd")
    _, f2b_running = _f2b_command(["ping"])
    return templates.TemplateResponse("admin_security.html", {
        "request": request, "user": user,
        "banned_ips": banned_ips,
        "ssh_bans": ssh_bans,
        "f2b_running": f2b_running
    })

@app.post("/admin/security/unban")
async def admin_unban(request: Request, db: Session = Depends(get_db),
                      ip: str = Form(...), jail: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    _f2b_command(["set", jail, "unbanip", ip])
    return RedirectResponse(url="/admin/security?success=1", status_code=302)

@app.post("/admin/security/unban-all")
async def admin_unban_all(request: Request, db: Session = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    for ban in _get_banned_ips():
        _f2b_command(["set", ban["jail"], "unbanip", ban["ip"]])
    return RedirectResponse(url="/admin/security?success=1", status_code=302)

@app.post("/admin/security/ban")
async def admin_ban(request: Request, db: Session = Depends(get_db),
                    ip: str = Form(...), jail: str = Form(...)):
    user = await get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse(url="/login", status_code=302)
    _f2b_command(["set", jail, "banip", ip])
    return RedirectResponse(url="/admin/security?success=1", status_code=302)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

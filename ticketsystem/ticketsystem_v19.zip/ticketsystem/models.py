from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Enum, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime
import enum

class TicketStatus(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    resolved = "resolved"
    closed = "closed"

class TicketPriority(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(200), nullable=False)
    feuerwehr = Column(String(200), nullable=True)
    loeschbezirk = Column(String(200), nullable=True)
    telefon = Column(String(50), nullable=True)
    funktion = Column(String(100), nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    tickets = relationship("Ticket", back_populates="user")
    comments = relationship("Comment", back_populates="user")

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    status = Column(Enum(TicketStatus), default=TicketStatus.open)
    priority = Column(Enum(TicketPriority), default=TicketPriority.medium)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="tickets")
    comments = relationship("Comment", back_populates="ticket")
    attachments = relationship("TicketAttachment", back_populates="ticket")

    @property
    def ticket_number(self):
        year = self.created_at.year if self.created_at else 2025
        return f"TKT-{year}-{self.id:04d}"

    @property
    def status_label(self):
        labels = {"open": "Offen", "in_progress": "In Bearbeitung",
                  "resolved": "Gelöst", "closed": "Geschlossen"}
        return labels.get(self.status.value, self.status.value)

    @property
    def priority_label(self):
        labels = {"low": "Niedrig", "medium": "Mittel",
                  "high": "Hoch", "critical": "Kritisch"}
        return labels.get(self.priority.value, self.priority.value)

class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    ticket = relationship("Ticket", back_populates="comments")
    user = relationship("User", back_populates="comments")

class TicketAttachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(200), nullable=False)
    filepath = Column(String(500), nullable=False)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    ticket = relationship("Ticket", back_populates="attachments")

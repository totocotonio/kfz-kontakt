#!/bin/bash
# Automatisches Backup der Ticketsystem-Datenbank
BACKUP_DIR="/opt/ticketsystem/backups"
DB_PATH="/opt/ticketsystem/tickets.db"
DATE=$(date +%Y-%m-%d_%H-%M)
BACKUP_FILE="$BACKUP_DIR/tickets_$DATE.db"

mkdir -p "$BACKUP_DIR"

# Datenbank kopieren
cp "$DB_PATH" "$BACKUP_FILE"

# Uploads auch sichern
tar -czf "$BACKUP_DIR/uploads_$DATE.tar.gz" -C /opt/ticketsystem uploads/ 2>/dev/null

# Alte Backups löschen (älter als 30 Tage)
find "$BACKUP_DIR" -name "*.db" -mtime +30 -delete
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete

echo "[BACKUP] Backup erstellt: $BACKUP_FILE"

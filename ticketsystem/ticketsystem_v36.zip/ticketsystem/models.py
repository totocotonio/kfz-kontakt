from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Enum, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

def _now():
    return datetime.now(timezone.utc).astimezone(ZoneInfo("Europe/Berlin")).replace(tzinfo=None)
import enum

class TicketStatus(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    resolved = "resolved"
    closed = "closed"

class TicketPriority(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(200), nullable=False)
    feuerwehr = Column(String(200), nullable=True)
    loeschbezirk = Column(String(200), nullable=True)
    telefon = Column(String(50), nullable=True)
    funktion = Column(String(100), nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=_now)
    tickets = relationship("Ticket", back_populates="user")
    comments = relationship("Comment", back_populates="user")
    reset_tokens = relationship("PasswordResetToken", back_populates="user")

class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"
    id = Column(Integer, primary_key=True, index=True)
    token = Column(String(100), unique=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=_now)
    user = relationship("User", back_populates="reset_tokens")

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    status = Column(Enum(TicketStatus), default=TicketStatus.open)
    priority = Column(Enum(TicketPriority), default=TicketPriority.medium)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=_now)
    updated_at = Column(DateTime, default=_now)
    last_user_activity = Column(DateTime, nullable=True)
    first_response_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    user = relationship("User", back_populates="tickets")
    comments = relationship("Comment", back_populates="ticket")
    attachments = relationship("TicketAttachment", back_populates="ticket")
    admin_notes = relationship("AdminNote", back_populates="ticket")
    history = relationship("TicketHistory", back_populates="ticket", order_by="TicketHistory.created_at")

    @property
    def ticket_number(self):
        year = self.created_at.year if self.created_at else 2025
        return f"TKT-{year}-{self.id:04d}"

    @property
    def status_label(self):
        labels = {"open": "Offen", "in_progress": "In Bearbeitung",
                  "resolved": "Gelöst", "closed": "Geschlossen"}
        return labels.get(self.status.value, self.status.value)

    @property
    def priority_label(self):
        labels = {"low": "Niedrig", "medium": "Mittel",
                  "high": "Hoch", "critical": "Kritisch"}
        return labels.get(self.priority.value, self.priority.value)

class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=_now)
    ticket = relationship("Ticket", back_populates="comments")
    user = relationship("User", back_populates="comments")

class TicketAttachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(200), nullable=False)
    filepath = Column(String(500), nullable=False)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    created_at = Column(DateTime, default=_now)
    ticket = relationship("Ticket", back_populates="attachments")

class AdminNote(Base):
    __tablename__ = "admin_notes"
    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    admin_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=_now)
    ticket = relationship("Ticket", back_populates="admin_notes")
    admin = relationship("User")

class TicketHistory(Base):
    __tablename__ = "ticket_history"
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    changed_by_id = Column(Integer, ForeignKey("users.id"))
    field = Column(String(50), nullable=False)
    old_value = Column(String(200), nullable=True)
    new_value = Column(String(200), nullable=True)
    created_at = Column(DateTime, default=_now)
    ticket = relationship("Ticket", back_populates="history")
    changed_by = relationship("User")
